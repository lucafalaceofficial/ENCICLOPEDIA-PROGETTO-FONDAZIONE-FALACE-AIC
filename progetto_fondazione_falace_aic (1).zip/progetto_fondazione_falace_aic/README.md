# Progetto Fondazione Falace delle Attività Intellettive Creative AIC

Enciclopedia in stile Wikipedia dedicata al patrimonio del Dott. Luca Falace.

## Struttura
- `frontend/`: applicazione React con architettura Wikipedia-like
- `backend/`: FastAPI con endpoint di download (ZIP / JSON / HTML)

## Sezioni principali
- Biblioteca (50 monografie)
- Bibliografia (brevetti UIBM, Google Patents)
- Biografia (Luca Falace, Lucio Falace, tradizione familiare)
- Media (apparizioni televisive MEDIASET, RAI 2, Premio Ecomondo)

Generato automaticamente dal portale.
