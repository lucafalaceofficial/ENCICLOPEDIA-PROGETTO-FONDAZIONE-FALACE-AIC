import { useEffect } from 'react';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import EncyclopediaLayout from './components/encyclopedia/EncyclopediaLayout';
import MainPage from './components/encyclopedia/MainPage';
import ArticlePage from './components/encyclopedia/ArticlePage';
import SearchResults from './components/encyclopedia/SearchResults';
import CategoryPage from './components/encyclopedia/CategoryPage';
import AllArticles from './components/encyclopedia/AllArticles';

function App() {
  useEffect(() => {
    document.title = 'Progetto Fondazione Falace AIC — Enciclopedia';
  }, []);
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<EncyclopediaLayout />}>
            <Route index element={<MainPage />} />
            <Route path="wiki/:slug" element={<ArticlePage />} />
            <Route path="cerca" element={<SearchResults />} />
            <Route path="categoria/:name" element={<CategoryPage />} />
            <Route path="indice" element={<AllArticles />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
