import { Outlet, Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Search, Download } from 'lucide-react';
import { CATEGORIES, TOTAL_COUNT } from '../../data/articles';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

export default function EncyclopediaLayout() {
  const [q, setQ] = useState('');
  const nav = useNavigate();

  const submit = (e) => {
    e.preventDefault();
    const query = q.trim();
    if (!query) return;
    nav(`/cerca?q=${encodeURIComponent(query)}`);
  };

  return (
    <>
      <header className="wp-topbar" data-testid="wp-header">
        <div className="wp-topbar-inner">
          <Link to="/" className="wp-logo" data-testid="logo-home-link">
            <div className="wp-logo-mark">F</div>
            <div className="wp-logo-text">
              <span className="wp-logo-title">Progetto Fondazione Falace</span>
              <span className="wp-logo-sub">Delle Attività Intellettive Creative AIC · di Luca Falace</span>
            </div>
          </Link>
          <form className="wp-search" onSubmit={submit} data-testid="search-form">
            <Search size={14} color="#54595d" />
            <input
              data-testid="search-input"
              placeholder="Cerca nell'enciclopedia"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <button type="submit" data-testid="search-submit">Cerca</button>
          </form>
          <div className="wp-topbar-links">
            <Link to="/indice" data-testid="header-index-link">Indice</Link>
            <Link to="/" data-testid="header-main-link">Pagina principale</Link>
          </div>
        </div>
      </header>

      <div className="wp-layout">
        <aside className="wp-sidebar">
          <div className="wp-sidebar-portal">
            <h4 className="wp-sidebar-heading">Navigazione</h4>
            <ul>
              <li><Link to="/">Pagina principale</Link></li>
              <li><Link to="/indice">Tutte le voci</Link></li>
              <li><Link to="/wiki/fondazione_falace_aic">La Fondazione</Link></li>
              <li><Link to="/wiki/luca_falace">Biografia di Luca Falace</Link></li>
              <li><Link to="/wiki/paolo_falace">Biografia di Paolo Falace</Link></li>
              <li><Link to="/wiki/lucio_falace">Biografia di Lucio Falace</Link></li>
              <li><Link to="/wiki/sincronismo_creativo">Sincronismo Creativo</Link></li>
            </ul>
          </div>
          <div className="wp-sidebar-portal">
            <h4 className="wp-sidebar-heading">Le tre sezioni</h4>
            <ul>
              <li><Link to="/categoria/Libro">Biblioteca (Libri)</Link></li>
              <li><Link to="/categoria/Brevetto">Bibliografia (Brevetti)</Link></li>
              <li><Link to="/categoria/Biografia">Biografia</Link></li>
            </ul>
          </div>
          <div className="wp-sidebar-portal">
            <h4 className="wp-sidebar-heading">Categorie</h4>
            <ul>
              {CATEGORIES.map((c) => (
                <li key={c}>
                  <Link to={`/categoria/${encodeURIComponent(c)}`}>{c}</Link>
                </li>
              ))}
            </ul>
          </div>
          <div className="wp-sidebar-portal">
            <h4 className="wp-sidebar-heading">Strumenti</h4>
            <ul>
              <li><a href={`${BACKEND_URL}/api/download/zip`}>Scarica archivio ZIP</a></li>
              <li><a href={`${BACKEND_URL}/api/download/json`}>Scarica dati JSON</a></li>
              <li><a href={`${BACKEND_URL}/api/download/html`}>Scarica sito HTML</a></li>
            </ul>
          </div>
          <div className="wp-sidebar-portal" style={{ color: '#54595d', fontSize: 11 }}>
            <div>Voci enciclopediche: <strong>{TOTAL_COUNT}</strong></div>
          </div>
        </aside>

        <main className="wp-main">
          <Outlet />
          <footer className="wp-footer" data-testid="wp-footer">
            <div className="wp-download-menu" data-testid="download-menu">
              <a className="wp-download-cta" data-testid="download-zip-btn" href={`${BACKEND_URL}/api/download/zip`}>
                <Download size={14} /> File completo ZIP del portale
              </a>
              <a className="wp-download-cta" data-testid="download-json-btn" href={`${BACKEND_URL}/api/download/json`}>
                <Download size={14} /> Dati enciclopedia (JSON)
              </a>
              <a className="wp-download-cta" data-testid="download-html-btn" href={`${BACKEND_URL}/api/download/html`}>
                <Download size={14} /> Sito HTML statico
              </a>
            </div>
            <div>
              Progetto Fondazione Falace delle Attività Intellettive Creative AIC · Ideato dal Dott. Luca Falace ·
              Contenuti tutelati presso MiC/MiBAC, UIBM, OPAC SBN, CERN Zenodo, Dds e Museo MAXXI.
            </div>
          </footer>
        </main>
      </div>
    </>
  );
}
