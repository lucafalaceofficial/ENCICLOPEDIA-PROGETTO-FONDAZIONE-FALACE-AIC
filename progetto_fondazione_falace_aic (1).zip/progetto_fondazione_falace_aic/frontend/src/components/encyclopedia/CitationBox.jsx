import { useState } from 'react';

/**
 * CitationBox — genera citazioni verificate solo con identificatori realmente
 * presenti nell'infobox della voce (DOI Zenodo, ISBN, ASIN, numero brevetto,
 * link YouTube). Nessun identificatore inventato.
 */
export default function CitationBox({ article }) {
  const [format, setFormat] = useState('apa');
  const [copied, setCopied] = useState(false);

  const info = article.infobox || {};
  const year =
    info['Anno'] ||
    info['Anno deposito'] ||
    info['Prima edizione'] ||
    info['Data'] ||
    's.d.';
  const author = info['Autore'] || info['Inventore'] || info['Fondatore'] || 'Falace, L.';
  // Normalize author to "Cognome, N." if not already
  const normalizedAuthor = (() => {
    if (typeof author !== 'string') return 'Falace, L.';
    if (author.includes(',')) return author;
    const parts = author.replace(/^Dott\.\s*/i, '').replace(/^Ing\.\s*/i, '').trim().split(/\s+/);
    if (parts.length >= 2) {
      return `${parts[parts.length - 1]}, ${parts.slice(0, -1).map((p) => p[0] + '.').join(' ')}`;
    }
    return author;
  })();

  const title = article.title;
  const portal = 'Progetto Fondazione Falace delle Attività Intellettive Creative AIC';
  const url = typeof window !== 'undefined' ? window.location.href : '';
  const today = new Date().toLocaleDateString('it-IT', { day: '2-digit', month: 'long', year: 'numeric' });

  // Extract verified identifiers (only from infobox)
  const idents = [];
  const doi = info['DOI Zenodo'] || info['DOI'];
  const isbn = info['ISBN'] || info['ISBN prima ed.'];
  const asin = info['ASIN'];
  const patent = info['Numero brevetto'] || info['Numero'] || info['Brevetto premiato'];
  const youtube = info['Link YouTube'];
  if (doi && doi !== '—') idents.push({ label: 'DOI', value: doi, url: `https://doi.org/${String(doi).replace(/^https?:\/\/doi\.org\//i, '')}` });
  if (isbn && isbn !== '—') idents.push({ label: 'ISBN', value: isbn });
  if (asin && asin !== '—') idents.push({ label: 'ASIN', value: asin, url: `https://www.amazon.com/dp/${asin}` });
  if (patent && patent !== '—') idents.push({ label: 'Brevetto', value: patent });
  if (youtube && youtube !== '—' && /^https?:\/\//.test(youtube)) idents.push({ label: 'YouTube', value: youtube, url: youtube });

  const identsInline = idents.map((i) => `${i.label}: ${i.value}`).join(' · ');

  // === Formats ===
  const apa = () => {
    const parts = [`${normalizedAuthor} (${year}).`, `${title}.`, `In ${portal}.`];
    if (identsInline) parts.push(identsInline + '.');
    parts.push(`Consultato il ${today} da ${url}`);
    return parts.join(' ');
  };

  const iso690 = () => {
    const parts = [`${normalizedAuthor.toUpperCase()}. ${title}.`, `In: ${portal} [online].`, `${year}`];
    if (identsInline) parts.push(`${identsInline}.`);
    parts.push(`[consultato ${today}]. Disponibile da: ${url}`);
    return parts.join(' ');
  };

  const bibtex = () => {
    const key = article.slug.replace(/[^a-z0-9]+/gi, '_').slice(0, 40) + '_' + (year === 's.d.' ? 'sd' : String(year).slice(-4));
    const lines = [
      `@misc{${key},`,
      `  author  = {${normalizedAuthor}},`,
      `  title   = {${title.replace(/[{}]/g, '')}},`,
      `  year    = {${year}},`,
      `  howpublished = {${portal}},`,
    ];
    if (doi && doi !== '—') lines.push(`  doi     = {${String(doi).replace(/^https?:\/\/doi\.org\//i, '')}},`);
    if (isbn && isbn !== '—') lines.push(`  isbn    = {${isbn}},`);
    if (url) lines.push(`  url     = {${url}},`);
    lines.push(`  urldate = {${new Date().toISOString().slice(0, 10)}}`);
    lines.push('}');
    return lines.join('\n');
  };

  const plain = () => {
    const parts = [`${normalizedAuthor}. «${title}». ${portal}, ${year}.`];
    if (identsInline) parts.push(identsInline + '.');
    parts.push(`URL: ${url} (consultato il ${today}).`);
    return parts.join(' ');
  };

  const map = { apa: apa(), iso: iso690(), bibtex: bibtex(), plain: plain() };
  const current = map[format];

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(current);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch (e) {
      // fallback selection
      const ta = document.createElement('textarea');
      ta.value = current;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    }
  };

  return (
    <section data-testid="citation-section">
      <h2 id="cita_questa_voce">Cita questa voce</h2>
      <p style={{ color: '#54595d', fontSize: 12, fontFamily: 'sans-serif' }}>
        Citazione generata unicamente dagli identificatori verificati presenti in questa voce (DOI, ISBN, ASIN, numero brevetto). Nessun dato inventato.
      </p>
      <div className="wp-cite-tabs" data-testid="citation-format-tabs">
        {[
          { k: 'apa', label: 'APA 7' },
          { k: 'iso', label: 'ISO 690' },
          { k: 'bibtex', label: 'BibTeX' },
          { k: 'plain', label: 'Testo semplice' }
        ].map((t) => (
          <button
            key={t.k}
            data-testid={`citation-tab-${t.k}`}
            className={`wp-cite-tab ${format === t.k ? 'active' : ''}`}
            onClick={() => setFormat(t.k)}
            type="button"
          >
            {t.label}
          </button>
        ))}
      </div>
      <pre className="wp-cite-block" data-testid="citation-text">{current}</pre>
      <div className="wp-cite-actions">
        <button
          type="button"
          className="wp-download-cta"
          data-testid="citation-copy-btn"
          onClick={copy}
        >
          {copied ? '✓ Copiato negli appunti' : 'Copia citazione'}
        </button>
        {idents.length > 0 && (
          <span style={{ fontSize: 12, color: '#54595d', fontFamily: 'sans-serif' }}>
            Identificatori verificati: {idents.map((i) => (
              <span key={i.label} style={{ marginLeft: 8 }}>
                <strong>{i.label}</strong>: {i.url ? <a className="external" href={i.url} target="_blank" rel="noreferrer">{i.value}</a> : i.value}
              </span>
            ))}
          </span>
        )}
      </div>
    </section>
  );
}
