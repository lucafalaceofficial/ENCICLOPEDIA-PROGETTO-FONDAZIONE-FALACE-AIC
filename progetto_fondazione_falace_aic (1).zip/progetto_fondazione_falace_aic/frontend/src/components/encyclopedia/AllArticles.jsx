import { Link } from 'react-router-dom';
import { ARTICLES, CATEGORIES } from '../../data/articles';

export default function AllArticles() {
  return (
    <div className="wp-content">
      <h1 className="wp-firstheading">Indice generale delle voci</h1>
      <div className="wp-siteSub">Elenco completo di tutte le {ARTICLES.length} voci pubblicate</div>

      {CATEGORIES.map((cat) => {
        const list = ARTICLES.filter((a) => a.category === cat).sort((a, b) =>
          a.title.localeCompare(b.title, 'it')
        );
        if (!list.length) return null;
        return (
          <section key={cat}>
            <h2>{cat} <small style={{ color: '#54595d', fontWeight: 'normal', fontSize: 13 }}>({list.length})</small></h2>
            <ul className="wp-cat-list">
              {list.map((a) => (
                <li key={a.id}>
                  <Link to={`/wiki/${a.slug}`}>{a.title}</Link>
                </li>
              ))}
            </ul>
          </section>
        );
      })}
    </div>
  );
}
