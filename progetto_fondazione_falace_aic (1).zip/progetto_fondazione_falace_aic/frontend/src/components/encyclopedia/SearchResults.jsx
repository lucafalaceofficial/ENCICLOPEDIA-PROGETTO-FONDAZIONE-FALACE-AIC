import { Link, useSearchParams } from 'react-router-dom';
import { ARTICLES } from '../../data/articles';

export default function SearchResults() {
  const [params] = useSearchParams();
  const q = (params.get('q') || '').trim();
  const norm = q.toLowerCase();

  const results = !q
    ? []
    : ARTICLES.map((a) => {
        const hayTitle = a.title.toLowerCase();
        const hayCat = a.category.toLowerCase();
        const haySub = (a.subtitle || '').toLowerCase();
        const hayBody = a.sections
          .flatMap((s) => s.paragraphs || [])
          .join(' ')
          .toLowerCase();
        let score = 0;
        if (hayTitle.includes(norm)) score += 10;
        if (haySub.includes(norm)) score += 4;
        if (hayCat.includes(norm)) score += 3;
        if (hayBody.includes(norm)) score += 1;
        return { a, score };
      })
        .filter((x) => x.score > 0)
        .sort((x, y) => y.score - x.score);

  return (
    <div className="wp-content wp-search-results">
      <h1 className="wp-firstheading">Risultati della ricerca</h1>
      <div className="wp-siteSub">Ricerca per: <em>«{q}»</em> · {results.length} voci trovate</div>

      {results.length === 0 && q && (
        <p style={{ marginTop: 16 }}>Nessuna voce corrisponde alla ricerca.</p>
      )}

      {results.map(({ a }) => {
        const preview = (a.sections[0]?.paragraphs || [])[0] || '';
        return (
          <div key={a.id} style={{ margin: '16px 0' }}>
            <h3><Link to={`/wiki/${a.slug}`}>{a.title}</Link></h3>
            <div className="meta">{a.category} · /{a.slug}</div>
            <div className="snippet">{preview.slice(0, 260)}…</div>
          </div>
        );
      })}
    </div>
  );
}
