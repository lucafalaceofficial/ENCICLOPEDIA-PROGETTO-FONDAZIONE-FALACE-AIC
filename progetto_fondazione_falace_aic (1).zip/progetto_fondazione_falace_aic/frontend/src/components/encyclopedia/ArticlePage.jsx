import { useParams, Link, useNavigate } from 'react-router-dom';
import { ARTICLES_BY_SLUG, ARTICLES_BY_ID } from '../../data/articles';
import CitationBox from './CitationBox';

const tocId = (heading) => heading.toLowerCase().replace(/[^a-z0-9]+/g, '_');

export default function ArticlePage() {
  const { slug } = useParams();
  const nav = useNavigate();
  const a = ARTICLES_BY_SLUG[slug];

  if (!a) {
    return (
      <div className="wp-content">
        <h1 className="wp-firstheading">Voce non trovata</h1>
        <p>La voce richiesta non esiste. Torna alla <Link to="/">pagina principale</Link>.</p>
      </div>
    );
  }

  return (
    <>
      <div className="wp-tabs">
        <div className="wp-tab active">Voce</div>
        <div className="wp-tab" style={{ marginLeft: 'auto' }} onClick={() => window.print()} role="button">Stampa</div>
      </div>
      <div className="wp-content">
        <h1 className="wp-firstheading">{a.title}</h1>
        <div className="wp-siteSub">Da Enciclopedia Fondazione Falace AIC — Progetto delle Attività Intellettive Creative del Dott. Luca Falace.</div>

        {a.subtitle && <div className="wp-subtitle">{a.subtitle}</div>}

        <div className="wp-article">
          <div className="wp-article-main">
            {a.sections.length > 1 && (
              <div className="wp-toc">
                <div className="wp-toc-title">Indice</div>
                <ol>
                  {a.sections.map((s, i) => (
                    <li key={i}>
                      <a href={`#${tocId(s.heading)}`}>{s.heading}</a>
                    </li>
                  ))}
                  {a.seeAlso && a.seeAlso.length > 0 && (
                    <li><a href="#voci_correlate">Voci correlate</a></li>
                  )}
                  {a.references && a.references.length > 0 && (
                    <li><a href="#note_e_riferimenti">Note e riferimenti</a></li>
                  )}
                </ol>
              </div>
            )}

            {a.sections.map((s, i) => (
              <section key={i}>
                <h2 id={tocId(s.heading)}>{s.heading}</h2>
                {/* Rich sequential rendering when blocks are present (Archivio Storico) */}
                {s.blocks && s.blocks.length > 0 ? (
                  s.blocks.map((b, k) => {
                    if (b.type === 'p') {
                      return b.strong
                        ? <p key={k}><strong>{b.text}</strong></p>
                        : <p key={k}>{b.text}</p>;
                    }
                    if (b.type === 'hr') return <hr key={k} />;
                    if (b.type === 'list') {
                      const Tag = b.ordered ? 'ol' : 'ul';
                      return <Tag key={k}>{b.items.map((it, m) => <li key={m}>{it}</li>)}</Tag>;
                    }
                    if (b.type === 'table') {
                      return (
                        <table key={k} className="wikitable">
                          <thead><tr>{b.headers.map((h, m) => <th key={m}>{h}</th>)}</tr></thead>
                          <tbody>
                            {b.rows.map((r, m) => (
                              <tr key={m}>{r.map((c, n) => <td key={n}>{c}</td>)}</tr>
                            ))}
                          </tbody>
                        </table>
                      );
                    }
                    if (b.type === 'img') {
                      const desc = b.caption || `${a.title} — documento ${k + 1}`;
                      return (
                        <div key={k} data-testid="wp-image-block">
                          {/* INSERIRE QUI FOTO: {desc} */}
                          <figure className="wp-image-figure my-4">
                            <a href={b.src} target="_blank" rel="noreferrer">
                              <img
                                src={b.src}
                                alt={desc}
                                loading="lazy"
                                referrerPolicy="no-referrer"
                                onError={(e) => { e.currentTarget.style.display = 'none'; }}
                              />
                            </a>
                          </figure>
                          {/* Segnaposto Tailwind richiesto dalla direttiva (Zero Perdite) — sempre presente */}
                          <div
                            data-testid="wp-image-placeholder"
                            className="my-6 p-4 bg-slate-800/50 border-l-4 border-amber-500 rounded text-sm italic text-slate-300 flex flex-col items-center"
                          >
                            <span>[FOTO: {desc}]</span>
                            <a href={b.src} target="_blank" rel="noreferrer" className="text-[11px] not-italic text-amber-300 hover:text-amber-200 mt-1 break-all">{b.src}</a>
                          </div>
                        </div>
                      );
                    }
                    if (b.type === 'video') {
                      const desc = b.caption || `${a.title} — video ${k + 1}`;
                      return (
                        <div key={k} data-testid="wp-video-block">
                          {/* INSERIRE QUI VIDEO: {desc} */}
                          <figure className="wp-image-figure my-4">
                            <video controls preload="none" src={b.src} style={{ maxWidth: '100%' }} />
                          </figure>
                          <div
                            data-testid="wp-video-placeholder"
                            className="my-6 p-4 bg-slate-800/50 border-l-4 border-amber-500 rounded text-sm italic text-slate-300 flex flex-col items-center"
                          >
                            <span>[VIDEO: {desc}]</span>
                            <a href={b.src} target="_blank" rel="noreferrer" className="text-[11px] not-italic text-amber-300 hover:text-amber-200 mt-1 break-all">{b.src}</a>
                          </div>
                        </div>
                      );
                    }
                    if (b.type === 'embed') {
                      const url = b.url || '';
                      const desc = b.caption || `${a.title} — contenuto multimediale ${k + 1}`;
                      let embedSrc = null;
                      const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{6,})/);
                      const vm = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
                      if (yt) embedSrc = `https://www.youtube.com/embed/${yt[1]}`;
                      else if (vm) embedSrc = `https://player.vimeo.com/video/${vm[1]}`;
                      else if (/\/embed\//.test(url)) embedSrc = url;
                      return (
                        <div key={k} data-testid="wp-embed-block">
                          {/* INSERIRE QUI VIDEO/EMBED: {desc} */}
                          {embedSrc && (
                            <div className="wp-embed-frame my-4" style={{ position: 'relative', paddingBottom: '56.25%', height: 0, overflow: 'hidden' }}>
                              <iframe
                                src={embedSrc}
                                title={desc}
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen
                                loading="lazy"
                                style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', border: 0 }}
                              />
                            </div>
                          )}
                          <div
                            data-testid="wp-embed-placeholder"
                            className="my-6 p-4 bg-slate-800/50 border-l-4 border-amber-500 rounded text-sm italic text-slate-300 flex flex-col items-center"
                          >
                            <span>[VIDEO: {desc}]</span>
                            <a href={url} target="_blank" rel="noreferrer" className="text-[11px] not-italic text-amber-300 hover:text-amber-200 mt-1 break-all">{url}</a>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  })
                ) : (
                  <>
                    {(s.paragraphs || []).map((p, j) => (
                      <p key={j}>{p}</p>
                    ))}
                    {s.list && (
                      <ul>{s.list.map((it, k) => <li key={k}>{it}</li>)}</ul>
                    )}
                    {s.images && s.images.length > 0 && (
                      <div className="wp-image-gallery" data-testid="wp-image-gallery">
                        {s.images.map((src, k) => (
                          <figure key={k} className="wp-image-figure">
                            <a href={src} target="_blank" rel="noreferrer">
                              <img
                                src={src}
                                alt={`Documento visivo ${k + 1} — ${a.title}`}
                                loading="lazy"
                                onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.parentElement.parentElement.classList.add('wp-image-broken'); }}
                              />
                            </a>
                            <figcaption>
                              Immagine {k + 1} · <a className="external" href={src} target="_blank" rel="noreferrer">Apri originale</a>
                            </figcaption>
                          </figure>
                        ))}
                      </div>
                    )}
                  </>
                )}
                {s.externalLink && (
                  <p>
                    <a className="external" href={s.externalLink} target="_blank" rel="noreferrer">
                      {s.externalLink}
                    </a>
                  </p>
                )}
                {s.table && (
                  <table className="wikitable">
                    <thead>
                      <tr>
                        {s.table.headers.map((h, k) => <th key={k}>{h}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {s.table.rows.map((row, k) => (
                        <tr key={k}>
                          {row.map((cell, m) => {
                            const str = typeof cell === 'string' ? cell : String(cell || '');
                            const urlMatch = str.match(/(https?:\/\/[^\s]+)/);
                            if (urlMatch) {
                              const before = str.slice(0, urlMatch.index);
                              return (
                                <td key={m}>
                                  {before && <span>{before}</span>}
                                  <a className="external" href={urlMatch[1]} target="_blank" rel="noreferrer">Collegamento</a>
                                </td>
                              );
                            }
                            return <td key={m}>{cell}</td>;
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </section>
            ))}

            {a.seeAlso && a.seeAlso.length > 0 && (
              <section>
                <h2 id="voci_correlate">Voci correlate</h2>
                <ul>
                  {a.seeAlso.map((id) => {
                    const rel = ARTICLES_BY_ID[id];
                    if (!rel) return <li key={id}><span className="new-page">{id}</span></li>;
                    return (
                      <li key={id}>
                        <Link to={`/wiki/${rel.slug}`}>{rel.title}</Link>
                      </li>
                    );
                  })}
                </ul>
              </section>
            )}

            {a.references && a.references.length > 0 && (
              <section>
                <h2 id="note_e_riferimenti">Note e riferimenti</h2>
                <ol>
                  {a.references.map((r, i) => <li key={i}>{r}</li>)}
                </ol>
              </section>
            )}

            <section>
              <h2>Categoria</h2>
              <p>
                <Link to={`/categoria/${encodeURIComponent(a.category)}`}>{a.category}</Link>
              </p>
            </section>

            <CitationBox article={a} />
          </div>

          {a.infobox && Object.keys(a.infobox).length > 0 && (
            <aside className="wp-infobox">
              <div className="wp-infobox-title">{a.title}</div>
              <div className="wp-infobox-subtitle">{a.category}</div>
              {a.image && a.image.url && (
                <figure className="wp-infobox-figure" style={{ margin: 0, padding: 8, borderBottom: '1px solid #a2a9b1', background: '#f8f9fa' }}>
                  <a href={a.image.url} target="_blank" rel="noreferrer">
                    <img
                      src={a.image.url}
                      alt={a.title}
                      style={{ width: '100%', height: 'auto', display: 'block' }}
                      onError={(e) => { e.currentTarget.parentElement.parentElement.style.display = 'none'; }}
                    />
                  </a>
                  {a.image.caption && (
                    <figcaption style={{ fontSize: 11, color: '#54595d', padding: '6px 4px 0' }}>
                      {a.image.caption}
                    </figcaption>
                  )}
                </figure>
              )}
              <table>
                <tbody>
                  {Object.entries(a.infobox).map(([k, v]) => (
                    <tr key={k}>
                      <th>{k}</th>
                      <td>{typeof v === 'string' && /^https?:\/\//.test(v) ? (
                        <a className="external" href={v} target="_blank" rel="noreferrer">{v}</a>
                      ) : String(v)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </aside>
          )}
        </div>
      </div>
    </>
  );
}
