import { Link, useParams } from 'react-router-dom';
import { ARTICLES } from '../../data/articles';

export default function CategoryPage() {
  const { name } = useParams();
  const decoded = decodeURIComponent(name);
  const list = ARTICLES.filter((a) => a.category === decoded).sort((a, b) =>
    a.title.localeCompare(b.title, 'it')
  );

  return (
    <div className="wp-content">
      <h1 className="wp-firstheading">Categoria: {decoded}</h1>
      <div className="wp-siteSub">{list.length} voci in questa categoria</div>
      <p style={{ marginTop: 12, fontSize: 13, color: '#54595d' }}>
        Questa è una pagina di categoria dell'Enciclopedia della Fondazione Falace AIC. Contiene tutte le voci enciclopediche appartenenti alla categoria <strong>{decoded}</strong>.
      </p>

      <ul className="wp-cat-list">
        {list.map((a) => (
          <li key={a.id}>
            <Link to={`/wiki/${a.slug}`}>{a.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
