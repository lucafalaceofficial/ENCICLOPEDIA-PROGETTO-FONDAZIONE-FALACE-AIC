import { Link } from 'react-router-dom';
import { ARTICLES, ARTICLES_BY_ID, FEATURED, TOTAL_COUNT, CATEGORIES } from '../../data/articles';

export default function MainPage() {
  const featuredArticle = ARTICLES_BY_ID['sincronismo_creativo'];
  const bio = ARTICLES_BY_ID['luca_falace'];

  const perCategory = CATEGORIES.map((c) => ({
    name: c,
    count: ARTICLES.filter((a) => a.category === c).length
  }));

  const recent = ARTICLES.slice(-6);

  return (
    <div className="wp-mainpage">
      <div className="wp-welcome-box">
        <h1 className="wp-welcome-title">Benvenuti nell'Enciclopedia della Fondazione Falace AIC</h1>
        <div className="wp-welcome-sub">
          Il progetto enciclopedico dedicato alle <em>Attività Intellettive Creative</em> del Dott. Luca Falace &mdash; Biblioteca, Bibliografia, Biografia
        </div>
        <div className="wp-welcome-stats">
          Voci pubblicate: <strong>{TOTAL_COUNT}</strong> · Categorie: <strong>{CATEGORIES.length}</strong> · Aggiornata al 2026
        </div>
      </div>

      <div className="wp-cols">
        <div className="wp-box">
          <div className="wp-box-header">In evidenza — {featuredArticle.title}</div>
          <div className="wp-box-body">
            <p>{featuredArticle.sections[0].paragraphs[0]}</p>
            <p>
              <Link to={`/wiki/${featuredArticle.slug}`}>Continua a leggere ›</Link>
            </p>
          </div>
        </div>

        <div className="wp-box">
          <div className="wp-box-header">Biografia — {bio.title}</div>
          <div className="wp-box-body">
            <p>{bio.sections[0].paragraphs[0]}</p>
            <p>
              <Link to={`/wiki/${bio.slug}`}>Leggi la biografia completa ›</Link>
            </p>
          </div>
        </div>

        <div className="wp-box">
          <div className="wp-box-header">Voci principali</div>
          <div className="wp-box-body">
            <ul>
              {FEATURED.map((id) => {
                const a = ARTICLES_BY_ID[id];
                if (!a) return null;
                return (
                  <li key={id}>
                    <Link to={`/wiki/${a.slug}`}>{a.title}</Link>{' '}
                    <small style={{ color: '#54595d' }}>({a.category})</small>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        <div className="wp-box">
          <div className="wp-box-header">Categorie</div>
          <div className="wp-box-body">
            <ul>
              {perCategory.map((c) => (
                <li key={c.name}>
                  <Link to={`/categoria/${encodeURIComponent(c.name)}`}>{c.name}</Link>{' '}
                  <small style={{ color: '#54595d' }}>({c.count} voci)</small>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="wp-box" style={{ gridColumn: '1 / -1' }}>
          <div className="wp-box-header">Ultime voci aggiunte</div>
          <div className="wp-box-body">
            <ul>
              {recent.map((a) => (
                <li key={a.id}>
                  <Link to={`/wiki/${a.slug}`}>{a.title}</Link>{' '}
                  <small style={{ color: '#54595d' }}>&mdash; {a.category}</small>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
