

export const SYNC_LEVELS = [
  {
    level: 1,
    titleIt: 'Coincidenza Semplice',
    titleEn: 'Simple Coincidence',
    descriptionIt: 'La percezione iniziale di eventi paralleli non intenzionali.',
    descriptionEn: 'The initial perception of unintentional parallel events.',
    experimentalBriefIt: 'Frequenze Delta: 0.5–4 Hz. Monitoraggio iniziale delle anomalie fortuite e casualità d\'evento nel quotidiano.',
    experimentalBriefEn: 'Delta bands: 0.5–4 Hz. Ordinary baseline monitoring of daily accidental and casual occurrences.',
    scientificAnalogIt: 'Analisi descrittiva statistica, deviazioni standard dello spazio di probabilità.',
    scientificAnalogEn: 'Descriptive statistical analysis, standard deviation of the probability space.'
  },
  {
    level: 2,
    titleIt: 'Risonanza Empatica',
    titleEn: 'Empathetic Resonance',
    descriptionIt: 'Connessioni emotive, mentali o psichiche repentine tra soggetti. Certificata nell\'esperimento EEG 2014 condotto su 200 soggetti simultanei.',
    descriptionEn: 'Sudden emotional, mental, or psychic connections between subjects. Certified in the 2014 EEG experiment conducted on 200 simultaneous subjects.',
    experimentalBriefIt: 'Frequenze Theta: 4–8 Hz. Rilevazione e sincronizzazione di fase inter-personale simultanea in gruppi coesi.',
    experimentalBriefEn: 'Theta bands: 4–8 Hz. Detection and tracking of simultaneous phase coherence across group members.',
    scientificAnalogIt: 'Accoppiamento oscillatorio simpatico cerebrale e ritmi empatici.',
    scientificAnalogEn: 'Sympathetic cerebral wave coupling and empathetic rhythmic locking.'
  },
  {
    level: 3,
    titleIt: 'Sincronismo Creativo',
    titleEn: 'Creative Synchronism',
    descriptionIt: 'La convergenza intenzionale di accadimenti paralleli indotta o catalizzata mediante l\'atto d\'arte o scrittura.',
    descriptionEn: 'The intentional convergence of parallel events induced or catalyzed through the act of art or writing.',
    experimentalBriefIt: 'Frequenze Alpha: 8–12 Hz. Stato di sintonizzazione ideativa fluida durante performance d\'arte e stesura testi.',
    experimentalBriefEn: 'Alpha bands: 8–12 Hz. Fluid creative flow activation during art generation and manuscript writing.',
    scientificAnalogIt: 'Vettore d\'onda d\'accordo estetico del segnale d\'intento.',
    scientificAnalogEn: 'Wave vector representation of intentional artistic resonance.'
  },
  {
    level: 4,
    titleIt: 'Campo Attivo',
    titleEn: 'Active Field',
    descriptionIt: 'La propagazione dell\'influenza intenzionale generata tramite produzione intellettiva continuativa ad alta frequenza.',
    descriptionEn: 'The propagation of intentional influence generated through continuous, high-frequency intellectual production.',
    experimentalBriefIt: 'Frequenze Beta Bassa: 12–20 Hz. Flusso di produzione e focalizzazione continuata ad alta densità ideativa.',
    experimentalBriefEn: 'Low Beta bands: 12–20 Hz. Flow of continuous production and focused concentration of high ideational density.',
    scientificAnalogIt: 'Propagazione energetica d\'onda del campo d\'attenzione locale.',
    scientificAnalogEn: 'Localized attention field wave energy propagation.'
  },
  {
    level: 5,
    titleIt: 'Sincronicità Operativa (Brevettuale)',
    titleEn: 'Operational Synchronicity (Patent)',
    descriptionIt: 'La convergenza d\'intuito utile a risolvere enigmi meccanici e funzionali (sviluppo brevetti GeniusOm e tutele legali).',
    descriptionEn: 'The convergence of insight useful for solving mechanical and functional enigmas (development of GeniusOm patents and legal protections).',
    experimentalBriefIt: 'Gamma e Beta: Stato d\'intuito risolutivo focalizzato per sbloccare design funzionali e brevetti industriali di famiglia.',
    experimentalBriefEn: 'Gamma & Beta bands: Focused problem-solving state configured to unlock functional designs and industrial family patents.',
    scientificAnalogIt: 'Definizione e formalizzazione del modello di risparmio energetico endogeno.',
    scientificAnalogEn: 'Mathematical optimization of endogenous energetic savings in industrial systems.'
  },
  {
    level: 6,
    titleIt: 'Sincronicità Generativa',
    titleEn: 'Generative Synchronicity',
    descriptionIt: 'Accoppiamento di risonanze biologiche (EEG, HRV) con riscontri pratici e invenzioni fisiche repentine.',
    descriptionEn: 'Coupling of biological resonances (EEG, HRV) with practical feedback and sudden physical inventions.',
    experimentalBriefIt: 'Integrazione EEG ed HRV. Allineamento coerente cervello-cuore associato a riscontri fisici nello spettro di frequenza.',
    experimentalBriefEn: 'EEG and HRV integration. Coherent brain-heart phase lock coupled with tangible feedback outputs.',
    scientificAnalogIt: 'Trasduzione fisica degli impulsi biologici e onde cardiache.',
    scientificAnalogEn: 'Direct physical transduction of biological pulses and cardiac wave flows.'
  },
  {
    level: 7,
    titleIt: 'Sincronicità Magnetica (Imprenditoriale)',
    titleEn: 'Magnetic Synchronicity (Entrepreneurial)',
    descriptionIt: 'Attrazione oggetiva e amplificata delle risorse di sostegno e d\'investimento finanziario (es. Shark Tank €250k).',
    descriptionEn: 'Objective and amplified attraction of support resources and financial investments (e.g. Shark Tank €250k).',
    experimentalBriefIt: 'Stato di coerenza magnetica globale misurata durante traguardi d\'impresa e attrazioni di capitali.',
    experimentalBriefEn: 'Global coherence states recorded during major business achievements and capital attraction milestones.',
    scientificAnalogIt: 'Fattore d\'attrazione di flussi d\'interesse economico e sintonizzazione d\'intento.',
    scientificAnalogEn: 'Tuning coefficient of economic flow attraction and intent configuration.'
  },
  {
    level: 8,
    titleIt: 'Campo Unificato',
    titleEn: 'Unified Field',
    descriptionIt: 'L\'integrazione consapevole fra frequenze quantistiche (alte) e bio-frequenze umane (basse) nello stesso spettro Hz.',
    descriptionEn: 'The conscious integration of microscopic quantum frequencies (high) and human bio-frequencies (low) within the same continuous Hz spectrum.',
    experimentalBriefIt: 'Gamma Alta (>40 Hz). Interazione sintonica delle onde neurali d\'alto livello con il campo risonante locale.',
    experimentalBriefEn: 'High Gamma bands (>40 Hz). Sympathetic integration of high-level brainwaves with the local resonant carrier.',
    scientificAnalogIt: 'Modellazione di risonanza armonica dell\'interazione mente-campo.',
    scientificAnalogEn: 'Harmonic resonance modeling of mind-field interaction dynamics.'
  },
  {
    level: 9,
    titleIt: 'Sincronicità Cosmica',
    titleEn: 'Cosmic Synchronicity',
    descriptionIt: 'Allineamento totale con dissoluzione del tempo lineare, risonanze coerenti di Schumann a 7.83Hz con l\'ordine implicito cosmico.',
    descriptionEn: 'Absolute alignment with dissolution of linear time, mirroring coherent Schumann resonances at 7.83Hz with the cosmic implicate order.',
    experimentalBriefIt: 'Massimo picco hertziano di risonanza. Coerenza interemisferica stabile > 90% in risonanza con il segnale planetario a 7.83 Hz.',
    experimentalBriefEn: 'Peak resonance state. Stable interhemispheric coherence > 90% phase-locked to the planetary 7.83 Hz Schumann cavity.',
    scientificAnalogIt: 'Formalizzazione della Legge Universale S = φ(f).',
    scientificAnalogEn: 'Unified mathematical formalization of the Universal S = φ(f) Law.'
  }
];

export const COMPARATIVE_MODELS = [
  {
    author: 'John Keely',
    theory: 'Sympathetic Vibratory Physics',
    period: 'XIX Secolo',
    summary: 'Scoperta e formalizzazione delle risonanze simpatiche strutturali della materia: ogni elemento vibra a frequenze peculiari e può essere movimentato per attrazione sintonica.',
    relevance: 'Fornisce le basi teoriche e meccaniche per comprendere come la vibrazione acustica agisca sulla materia densa.'
  },
  {
    author: 'Nikola Tesla',
    theory: 'Risonanza Elettromagnetica Estesa',
    period: 'XX Secolo (Inizio)',
    summary: 'La concezione per cui il globo terrestre e la ionosfera formano un gigantesco condensatore risonante, in cui l\'energia può essere propagata ad ogni distanza senza sensibili perdite.',
    relevance: 'Dimostra la trasmissione di energia non localizzata geograficamente attraverso campi elettromagnetici coerenti.'
  },
  {
    author: 'CIA / Monroe Institute',
    theory: 'Gateway Process / Hemi-Sync',
    period: '1970–1980',
    summary: 'Studi declassificati sui protocolli di alterazione e sintonizzazione degli emisferi cerebrali per mezzo di frequenze sonore differenziali (battimenti binaurali), connettendo la mente a piani non-locali.',
    relevance: 'Verifica empiricamente che la coscienza umana vive e si espande modulata e stimolata da precise sorgenti di frequenza Hz.'
  },
  {
    author: 'Dott. Luca Falace',
    theory: 'Modello AIC-EC-HZ',
    period: '2005–2026',
    summary: 'La prima unificazione strutturata dei campi elettromagnetici quantistici microscopici con le risonanze biologiche a bassa frequenza (EEG, HRV) nell\'unico asse hertziano continuo.',
    relevance: 'Sintesi contemporanea certificata Zenodo DOI, che rende operativo il legame tra coscienza creativa e potenziale d\'evento fisico.'
  }
];

export const LHCB_RESPONSE_PAPER = {
  title: 'Risposta scientifica all\'esperimento LHCb sul Barione Ξcc⁺ (Doppiamente Charmato)',
  year: 2026,
  fileId: 'Falace_Xicc_v3_2026',
  context: 'La collaborazione scientifica internazionale LHCb presso il CERN di Ginevra ha annunciato la scoperta del barione doppiamente charmato Ξcc⁺. Luca Falace ha elaborato e depositato una dettagliata risposta analitica.',
  keyHypothesis: 'L\'interazione e lo spin dei quark nei barioni doppiamente charmati rispondono a relazioni geometriche di risonanza armonica hertziana quantistica compatibili con il modello di oscillazione del campo AIC-EC-HZ.',
  implications: 'Se dimostrato, conferma che la massa e l\'energia delle particelle elementari sono espressione di schemi geometrici di risonanza su scala sub-nucleare.'
};
