

export const EXHIBITIONS = [
  {
    id: 'exh-2012-capodimonte',
    titleIt: 'La Dimostrazione Originaria: Sincronismo Creativo e Performance AIC',
    titleEn: 'The Original Demonstration: Creative Synchronism and AIC Performance',
    year: 2012,
    datesIt: 'Venerdì 28 Settembre 2012 (Orario: 19:00 - 02:00)',
    datesEn: 'Friday, September 28, 2012 (Time: 7:00 PM - 2:00 AM)',
    venueIt: 'Cortile del Museo di Capodimonte',
    venueEn: 'Courtyard of the Capodimonte Museum',
    introIt: "Il 28 settembre 2012, la prestigiosa cornice del Museo di Capodimonte ha fatto da teatro al debutto ufficiale della teoria del Sincronismo Creativo. In una sessione notturna tra arte, scienza e musica, il Dott. Luca Falace ha dato una dimostrazione pratica e fenomenologica delle Attività Intellettive Creative (AIC). Di fronte al pubblico, l'autore ha eseguito una performance dal vivo (Esperimento 1 e 2), tracciando la fitta scrittura automatica e i segni simbolici direttamente su grandi superfici verticali.",
    introEn: "On September 28, 2012, the prestigious setting of the Capodimonte Museum served(AIC). In front of the public, the author executed a live performance (Experiment 1 and 2), tracing dense automatic writing and symbolic signs directly on large vertical surfaces.",
    hasVerificationBadge: true,
    copyrightNoteIt: "Sincronismo Creativo - Registrato presso il Ministero dei Beni Culturali nel 2005. © Copyright Luca Falace.",
    copyrightNoteEn: "Creative Synchronism - Registered with the Ministry of Cultural Heritage in 2005. © Copyright Luca Falace.",
    validationLink: 'http://www.youtube.com/watch?v=S7f3Ucwpcj4',
    validationTitleIt: 'Video Documentario YouTube / Canale Ufficiale',
    validationTitleEn: 'Official Documentary Video YouTube',
    albums: [
      {
        id: 'album-2012-capodimonte',
        titleIt: 'Performance Live al Museo di Capodimonte',
        titleEn: 'Live Performance at Capodimonte Museum',
        contentIt: 'Documentazione fotografica ufficiale della performance notturna di scrittura e pittura automatica svoltasi nel cortile monumentale del Museo di Capodimonte.',
        contentEn: 'Official photographic documentation of the nocturnal live writing and automatic painting performance held in the monumental courtyard of the Capodimonte Museum.',
        photosCount: 30,
        link: 'https://photos.app.goo.gl/67QE5qQ9r6TNPh458',
        tags: ['#MuseoCapodimonte', '#PerformanceLive', '#Esperimento1e2', '#ScritturaAutomatica']
      }
    ]
  },
  {
    id: 'exh-2013-evento-zero',
    titleIt: 'Il Manifesto Zero: Sincronismo Creativo e Sperimentazione AIC',
    titleEn: 'The Manifesto Zero: Creative Synchronism and AIC Experimentation',
    year: 2013,
    datesIt: '21 Febbraio 2013',
    datesEn: 'February 21, 2013',
    venueIt: 'Galleria d\'arte, allestimento radicale',
    venueEn: 'Art gallery, radical setup',
    introIt: "Il 21 Febbraio 2013 segna la nascita pubblica della sperimentazione applicata del Dott. Luca Falace. Questo evento promozionale indipendente è stato interamente consacrato alle Attività Intellettive Creative (AIC) e alla pittura automatica. In un allestimento radicale e puro, l'autore ha esposto le prime tele generate attraverso la fenomenologia dell'inconscio e la scrittura simbolica, mettendole in diretto dialogo con la sua produzione saggistica. Al centro dello spazio espositivo, l'opera cardine: il volume 'Sincronismo Creativo', matrice teorica e filosofica dell'intero impianto della Fondazione.",
    introEn: "February 21, 2013, marks the public birth of Dr. Luca Falace's applied experimentation. This independent promotional event was entirely consecrated to Intellectual Creative Activities (AIC) and automatic painting. In a radical and pure setup, the author exhibited the first canvases generated through the phenomenology of the unconscious and symbolic writing, placing them in direct dialogue with his essayistic production. At the center of the exhibition space, the fundamental work: the volume 'Creative Synchronism', the theoretical and philosophical matrix of the entire Foundation.",
    hasVerificationBadge: true,
    copyrightNoteIt: "Sincronismo Creativo - Registrato presso il Ministero dei Beni Culturali nel 2005. © Copyright Luca Falace.",
    copyrightNoteEn: "Creative Synchronism - Registered with the Ministry of Cultural Heritage in 2005. © Copyright Luca Falace.",
    albums: [
      {
        id: 'album-2013-manifesto-zero',
        titleIt: 'Il Manifesto Zero — Album d\'Archivio',
        titleEn: 'The Manifesto Zero — Archival Album',
        contentIt: 'Album fotografico originario del debutto della sperimentazione applicata e presentazione teorica indipendente dei saggi.',
        contentEn: 'Original photographic album of the debut of applied experimentation and independent theoretical presentation of essays.',
        photosCount: 20,
        link: 'https://photos.app.goo.gl/ePNW3gMtFdXqZ2bNA',
        tags: ['#ManifestoZero', '#PitturaAutomatica', '#EsperimentoInconscio', '#Saggistica']
      }
    ]
  },
  {
    id: 'exh-2013-san-severo',
    titleIt: 'Mostra Personale: Diacronia Figurativa e Sincronismo Creativo',
    titleEn: 'Solo Exhibition: Figurative Diachronism and Creative Synchronism',
    year: 2013,
    datesIt: '17 Aprile – 30 Aprile 2013',
    datesEn: 'April 17 – April 30, 2013',
    venueIt: 'Chiesa del Complesso Monumentale di San Severo al Pendino, Via Duomo 286',
    venueEn: 'Church of the Monumental Complex of San Severo al Pendino, Via Duomo 286',
    introIt: "L'autore, quale storico dell'arte, letterato ed infine artista e ricercatore autonomo espone il 'risultato' sempre in divenire di più di un decennio di studi. Le sue opere, come i volumi pubblicati, sono il documento che testimonia la lunga ricerca nel campo delle forme artistiche relative alla sfera degli eventi paralleli. Uno studio figurativo della storia dell'arte attraverso l'interpretazione dei molteplici stili nei diversi periodi storici fino a giungere a quello che l'autore stesso ha denominato SINCRONISMO CREATIVO. La scrittura e l'arte non sono speculazione intellettuale o artistica, ma strumenti per indagare nel pensiero culturale più alto di ogni tempo: il mistero dell'esistenza. L'arte assume il suo ruolo originario di archetipo quale mezzo di interazione con il mondo fenomenico e metafisico. L'arte e il simbolo si fondono grazie alla scrittura automatica simbolica, fenomenologia dell'inconscio che emerge durante la dimensione onirica e meditativa.",
    introEn: "The author,-evolving 'result' of more than a decade of studies. His works, like the published volumes, are the document that testifies to the long research in the field of artistic forms related to the sphere of parallel events. A figurative study of art history through the interpretation of multiple styles in different historical periods up to what the author himself has called CREATIVE SYNCHRONISM. Writing and art are not intellectual or artistic speculation, but tools to investigate the highest cultural thought of all time: the mystery of existence. Art assumes its original role",
    patronageIt: 'Assessorato alla Cultura e al Turismo',
    patronageEn: 'Department of Culture and Tourism',
    designIt: 'Studio Pelella Architetti, Fabrizia Costacimino, Studio Vecci Architetti',
    designEn: 'Studio Pelella Architects, Fabrizia Costacimino, Studio Vecci Architects',
    photosByIt: 'Luca Falace, Paola Tufo, Bruno Rizzi',
    photosByEn: 'Luca Falace, Paola Tufo, Bruno Rizzi',
    publisherIt: 'Iemme Edizioni',
    publisherEn: 'Iemme Edizioni Publishing',
    hasVerificationBadge: true,
    specialEventIt: 'Sabato 20 aprile 2013, ore 12:00 - Aperitivo con l\'artista',
    specialEventEn: 'Saturday, April 20, 2013, 12:00 PM - Aperidrink with the artist',
    copyrightNoteIt: "Sincronismo Creativo - Registrato presso il Ministero dei Beni Culturali nel 2005. © Copyright Luca Falace (Studio degli Eventi Paralleli attraverso l'Analisi delle attività Artistiche e Scientifiche).",
    copyrightNoteEn: "Creative Synchronism - Registered with the Ministry of Cultural Heritage in 2005. © Copyright Luca Falace (Study of Parallel Events through the Analysis of Artistic and Scientific Activities).",
    validationLink: 'https://web.archive.org/web/20230223180353/http://www.comune.napoli.it/flex/cm/pages/ServeBLOB.php/L/IT/IDPagina/21376',
    validationTitleIt: 'Archivio Storico Comunale / Wayback Machine',
    validationTitleEn: 'Municipality Historical Archive / Wayback Machine',
    
    // Press Review Section
    pressTitleIt: 'Scrittura e pittura per indagare la creatività',
    pressTitleEn: 'Writing and Painting to Investigate Creativity',
    pressSubIt: "Falace - Un'opera in mostra a San Severo al Pendino",
    pressSubEn: 'Falace - An artwork on display at San Severo al Pendino',
    pressSourceIt: 'IL MATTINO',
    pressSourceEn: 'IL MATTINO Daily',
    pressAuthorIt: 'Daniela Ricci',
    pressAuthorEn: 'Daniela Ricci',
    pressTextIt: '«“Dal Diacronismo figurativo al Sincronismo creativo” è il titolo della personale di Luca Falace in corso al Complesso Monumentale di San Severo al Pendino in via Duomo 286, che intende indagare l\'arte che, attraverso i suoi simboli, assume un ruolo originario di archetipo. Falace, che da sempre studia il fenomeno delle divinazioni evidenziandone la relazione con il mondo del mito e delle tradizioni popolari, parla di eventi paralleli: \n\n“La scrittura e l\'arte non sono speculazione intellettuale o artistica, ma strumenti per indagare nel pensiero culturale più alto di ogni tempo: il mistero dell\'esistenza. L\'individuo pensante è consapevole della realtà che lo circonda – spiega l\'artista – e la mette in relazione al proprio stato d\'animo. E in questa analisi rientra anche la natura con il suo ritmo e i suoi percorsi variabili”. \n\nScrittura e pittura sono per l\'artista gli strumenti per indagare nel pensiero culturale e nel mistero dell\'esistenza. Attraverso uno studio figurativo della storia dell\'arte, e la creazione e interpretazione personalizzata di opere ispirate ai cambiamenti della pittura e la creatività nel corso dei secoli, Falace arriva poi a dipingere la sua visione del mondo passando con destrezza dal figurativo all\'astrattismo.»',
    pressTextEn: '«"From figurative diachronism to creative synchronism" is the title of Luca Falace\'s solo exhibition currently underway at the Monumental Complex of San Severo al Pendino in via Duomo 286, which intends to investigate art which, through its symbols, assumes an original role of archetype. Falace, who has always studied the phenomenon of divinations highlighting its relationship with the world of myth and popular traditions, speaks of parallel events: \n\n"Writing and art are not intellectual or artistic speculation, but tools to investigate the highest cultural thought of all time: the mystery of existence. The thinking individual is aware of the reality that surrounds them - explains the artist - and puts it in relation to their own state of mind. And nature with its rhythm and variable paths also falls into this analysis". \n\nWriting and painting are for the artist the tools to investigate cultural thought and the mystery of existence. Through a figurative study of art history, and the creation and personalized interpretation of works inspired by the changes in painting and creativity over the centuries, Falace then arrives at painting his vision of the world, passing with dexterity from figurative to abstractionism.»',
    
    // AIC Explanation
    aicCurationIt: "La mostra del 2013 rappresenta la prima vera sperimentazione sul campo del Sincronismo Creativo applicato alle Attività Intellettive Creative (AIC) pittoriche. L'indagine si è strutturata su due canali speculari:\n\n1. LA SEZIONE ASTRATTA (Scrittura Automatica): Opere generate attraverso la fenomenologia dell'inconscio in stato meditativo, dove il segno e la scrittura automatica simbolica captano e registrano le dinamiche degli eventi paralleli.\n\n2. LA SEZIONE FIGURATIVA (Pareidolia): Opere strutturate sul principio antropologico della pareidolia, guidando l'inconscio visivo dello spettatore a riconoscere archetipi profondi, forme storiche e miti primordiali nascosti nel tessuto cromatico.\n\nQuesto dualismo dimostra come l'artista passi con destrezza dal figurativo all'astrattismo, non per mero esercizio stilistico, ma come strumento d'indagine del pensiero culturale e del mistero dell'esistenza.",
    aicCurationEn: "The 2013 exhibition represents the first real field trial of Creative Synchronism applied to pictorial Creative Intellectual Activities (AIC). The research is structured on two mirroring channels:\n\n1. THE ABSTRACT SECTION (Automatic Writing): Works generated through the phenomenology of the unconscious in a meditative state, where the sign and symbolic automatic writing capture and register the dynamics of parallel events.\n\n2. THE FIGURATIVE SECTION (Pareidolia): Works structured on the anthropological principle of pareidolia, guiding the viewer's visual unconscious to recognize deep archetypes, historical forms, and primordial myths hidden within the chromatic texture.\n\nThis dualism demonstrates how the artist moves with dexterity from figurative to abstract style, not for mere stylistic exercise, but",
    
    // Total physical books & manuscripts
    allestimentoEmphasisIt: "La mostra unisce indissolubilmente l'opera visiva alla produzione saggistica e letteraria dell'autore.\n\n- Da un lato della navata del Complesso Monumentale erano esposte le opere pittoriche (Astratte e Figurative).\n- Dall'altro lato erano esposti tutti i volumi stampati e pubblicati dal Dott. Luca Falace, a testimonianza del profondo legame tra segno grafico e pensiero teorico.\n\nIL VOLUME MANIFESTO: In primo piano all'interno del percorso espositivo era presente il testo cardine della ricerca: \"SINCRONISMO CREATIVO\" (Terza Edizione) pubblicato da Iemme Edizioni. Questo saggio rappresenta la colonna vertebrale concettuale di tutte le mostre personali dell'autore, dove la teoria scientifico-antropologica degli eventi paralleli trova la sua immediata traduzione estetica sulle tele.",
    allestimentoEmphasisEn: "The exhibition indissolubly combines the visual artwork with the author's essayistic and literary production.\n\n- On one side of the nave of the Monumental Complex, the pictorial works (Abstract and Figurative) were exhibited.\n- On the other side, all the volumes printed and published by Dr. Luca Falace were displayed, testifying to the deep connection between graphic sign and theoretical thought.\n\nTHE MANIFESTO VOLUME: In the foreground within the exhibition itinerary was the fundamental research text: \"CREATIVE SYNCHRONISM\" (Third Edition) published by Iemme Edizioni. This essay represents the conceptual backbone of all the author's solo exhibitions, where the scientific-anthropological theory of parallel events finds its immediate aesthetic translation on canvas.",
    
    manuscriptsTitleIt: "Il Segno e la Parola: I Manoscritti di San Severo al Pendino",
    manuscriptsTitleEn: "The Sign and the Word: The Manuscripts of San Severo al Pendino",
    manuscriptsTextIt: "All'interno del percorso espositivo, adagiati su supporti curvi dedicati, sono stati presentati al pubblico tre monumentali volumi manoscritti inediti, redatti interamente a mano dall'autore in formato A4. I volumi testimoniano la fenomenologia dell'inconscio e la scrittura automatica simbolica applicata alla ricerca:\n\n- Manoscritto 1: Volume monumentale di circa 350 pagine (con note grafiche, schemi e testi fitti).\n- Manoscritto 2: Volume di circa 400 pagine (focalizzato sull'indagine antropologico-culturale).\n- Manoscritto 3: Volume di circa 500 pagine (raccolta saggistico-filosofica ed ermetica).\n\nQueste tre ricerche si inseriscono all'interno della monumentale produzione letteraria del Dott. Luca Falace, che vanta un corpus complessivo di ben 41 titoli pubblicati e depositati, le cui copertine storiche costituivano la controparte concettuale e installativa delle opere pittoriche esposte nella Chiesa.",
    manuscriptsTextEn: "Within the exhibition path, resting on dedicated curved supports, three monumental unpublished manuscript volumes were presented to the public, written entirely by hand by the author in A4 format. These volumes witness the phenomenology of the unconscious and symbolic automatic writing applied to research:\n\n- Manuscript 1: Monumental volume of about 350 pages (with dense text, schemas and graphical notes).\n- Manuscript 2: Volume of about 400 pages (focused on cultural-thought research).\n- Manuscript 3: Volume of about 500 pages (philosophical, essayistic and hermetic collection).\n\nThese three research manuscripts fit within the monumental literary production of Dr. Luca Falace, boasting a total corpus of 41 published and deposited titles, whose historical covers constituted the counterpart of the paintings exhibited in the Church.",
    
    albums: [
      {
        id: 'album-1-general',
        titleIt: 'ALBUM 1 — Archivio Storico Generale (Vol. 1)',
        titleEn: 'ALBUM 1 — General Historical Archive (Vol. 1)',
        contentIt: 'Raccolta documentaria completa (828 elementi storici della mostra). Servizio fotografico comprendente l\'intero corpus delle opere esposte nella navata centrale e i flussi di visitatori istituzionali.',
        contentEn: 'Complete documentary collection (828 historical elements of the exhibition). Coverage detailing the entire body of works displayed in the main nave and institutional visitor flows.',
        photosCount: 828,
        link: 'https://photos.app.goo.gl/6g5imkSWHcBqQGtr9',
        tags: ['#ArteFigurativa', '#SincronismoCreativo', '#MostraPersonale', '#FondazioneFalace']
      },
      {
        id: 'album-2-perf-b',
        titleIt: 'ALBUM 2 — Prospettiva Fotografica Professionale (Vol. 2)',
        titleEn: 'ALBUM 2 — Professional Photo Perspective (Vol. 2)',
        contentIt: 'Servizio fotografico professionale (Prospettiva B) specificamente dedicato alla resa plastica delle singole opere d\'arte astratte e figurative inserite nei supporti espositivi neri.',
        contentEn: 'Professional photo coverage (Perspective B) dedicated to rendering the three-dimensional presence of individual abstract and figurative artworks mounted on black monolithic display supports.',
        photosCount: 140,
        link: 'https://photos.app.goo.gl/HVbeF4TxViCpczV77',
        tags: ['#ServizioProfessionale', '#OpereInMostra', '#DiacroniaFigurativa', '#SanSevero']
      },
      {
        id: 'album-3-perf-c',
        titleIt: 'ALBUM 3 — Prospettiva Fotografica Professionale (Vol. 3)',
        titleEn: 'ALBUM 3 — Professional Photo Perspective (Vol. 3)',
        contentIt: 'Servizio fotografico professionale (Prospettiva C) dedicato ai dettagli dettagliati delle stesure cromatiche alchemiche, geometrie svelate e panoramiche d\'insieme dell\'architettura sacra.',
        contentEn: 'Professional photo coverage (Perspective C) focusing on details of alchemical color layers, geometric structures, and expansive wide-angle panoramas of the historical sacred architecture.',
        photosCount: 185,
        link: 'https://photos.app.goo.gl/PDD7AERXQfHVwzkZ6',
        tags: ['#PanoramicheSacra', '#DettagliOpere', '#ProspettivaC', '#StudioColore']
      },
      {
        id: 'album-4-backstage',
        titleIt: 'ALBUM 4 — Allestimento & Dietro le Quinte',
        titleEn: 'ALBUM 4 — Exhibition Layout & Backstage',
        contentIt: 'La sezione "Allestimento & Dietro le Quinte" offre uno sguardo inedito sulla genesi della mostra, evidenziando il dialogo preliminare tra lo spazio architettonico sacro e la disposizione geometrico-strutturale pianificata dall\'autore. Documentazione tecnica, montaggio delle strutture autoportanti e calibrazione spaziale della mostra.',
        contentEn: 'The "Exhibition Layout & Backstage" section offers an unprecedented look at the genesis of the show, highlighting the preliminary dialogue between the sacred architectural space and the geometric-structural layout planned by the author. Technical sheets, structure mounting, and spatial calibration.',
        photosCount: 64,
        link: 'https://photos.app.goo.gl/eXFc195fezg8NN85A',
        tags: ['#BackstageTecnico', '#ArchitetturaSacra', '#MontaggioMostra', '#StudioPelella']
      },
      {
        id: 'album-5-author',
        titleIt: 'ALBUM 5 — Ritratti e Presenza dell\'Autore',
        titleEn: 'ALBUM 5 — Portraits & Author Presence',
        contentIt: 'La raccolta documenta l\'attività relazionale e i momenti salienti del Dott. Luca Falace, catturando l\'interazione diretta con visitatori, stampa e critici all\'interno del complesso monumentale. Servizio biografico e accoglienza dell\'autore.',
        contentEn: 'The collection documents the public interactions and key moments of Dr. Luca Falace, capturing direct dialogue with visitors, press, and critics inside the monumental complex. Biographical records and author reception.',
        photosCount: 92,
        link: 'https://photos.app.goo.gl/gLDpAhDg3EvvfFjy9',
        tags: ['#LucaFalace', '#BiografiaAttiva', '#DialogoPubblico', '#IntervisteIstituzionali']
      },
      {
        id: 'album-6-mosaic',
        titleIt: 'ALBUM 6 — Sintesi e Mosaici Fotografici',
        titleEn: 'ALBUM 6 — Summaries & Photo Mosaics',
        contentIt: 'Attraverso composizioni grafiche multi-immagine, questa raccolta unisce dettagli microscopici delle opere e sequenze dell\'evento, restituendo una sintesi dinamica dell\'atmosfera della mostra, ideati per la fruizione istantanea.',
        contentEn: 'Through multi-image graphic compositing, this collection binds microscopic canvas patterns and event sequences, providing a fast, dynamic summary of the show appropriate for direct web review.',
        photosCount: 45,
        link: 'https://goo.gl/photos/qDzS8gEfQa6YGPzJ7',
        tags: ['#MosaicoGrafico', '#SintesiDinamica', '#ConsultazioneVeloce', '#VisualCollage']
      }
    ]
  },
  {
    id: 'exh-2014-citta-scienza',
    titleIt: 'La Democratizzazione del Metodo: Arte, Scienza, Sincronicità e Sincronismo Creativo',
    titleEn: 'The Democratization of the Method: Art, Science, Synchronicity and Creative Synchronism',
    year: 2014,
    datesIt: 'Marzo 2014 (Data Certa: 4 Marzo 2014)',
    datesEn: 'March 2014 (Certain Date: March 4, 2014)',
    venueIt: 'Città della Scienza',
    venueEn: 'Città della Scienza',
    introIt: "Nel 2014, il Dott. Luca Falace compie un'operazione di fondamentale continuità teorica: prende l'esatto esperimento di scrittura e pittura automatica che aveva eseguito personalmente nel 2012 al Museo di Capodimonte e lo propone direttamente al pubblico. L'allestimento include la proiezione del video della performance del 2012 e il logo del C.E.S.P., creando un ponte visivo immediato tra teoria, azione accademica e pratica collettiva democratica. L'evento rappresenta il protocollo delle Attività Intellettive Creative (AIC) in 6 punti offerto ai visitatori.",
    introEn: "In 2014, Dr. Luca Falace performs an operation of fundamental theoretical continuity: presenting the exact experiment of automatic writing and painting executed live in 2012 at the Capodimonte Museum directly to the public. The exhibition layout includes the projection of the 2012 performance video and the C.E.S.P. logo, creating an immediate visual bridge between theory, academic action, and democratic collective practice. The event showcases the 6-point protocol of Intellectual Creative Activities (AIC) structured for visitors.",
    hasVerificationBadge: true,
    copyrightNoteIt: "Sincronismo Creativo - Registrato presso il Ministero dei Beni Culturali nel 2005. © Copyright Luca Falace.",
    copyrightNoteEn: "Creative Synchronism - Registered with the Ministry of Cultural Heritage in 2005. © Copyright Luca Falace.",
    validationLink: 'https://lucafalace.altervista.org/arte-sincronica/',
    validationTitleIt: 'Documento d\'Archivio Digitale / Cronistoria Città della Scienza',
    validationTitleEn: 'Digital Archival Document / Timeline of Città della Scienza',
    albums: [
      {
        id: 'album-2014-citta-scienza',
        titleIt: 'Mostra Interattiva — Città della Scienza',
        titleEn: 'Interactive Exhibition — Città della Scienza',
        contentIt: 'Documentazione fotografica dell\'esperimento interattivo con il pubblico e del coinvolgimento collettivo tramite il Protocollo AIC in 6 punti a Città della Scienza.',
        contentEn: 'Photographic documentation of the interactive experiment with the public and collective involvement through the 6-point AIC Protocol in Città della Scienza.',
        photosCount: 50,
        link: 'https://photos.app.goo.gl/1a337o2F3HvyPHdk6',
        tags: ['#CittaDellaScienza', '#MostraInterattiva', '#ProtocolloAIC', '#Democratizzazione']
      }
    ]
  }
];
