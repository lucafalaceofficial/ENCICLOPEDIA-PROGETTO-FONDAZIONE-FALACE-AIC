// Aggregates all portal data into unified Wikipedia-like articles
import { BOOKS } from './books';
import { ARTWORKS, INSTITUTIONAL_VENUES } from './artworks';
import { INVENTIONS, INVENTORS_TRADITION } from './inventions';
import { SYNC_LEVELS, COMPARATIVE_MODELS, LHCB_RESPONSE_PAPER } from './theory';
import { EXHIBITIONS } from './exhibitions';
import { DOCUMENTARY_SERIES } from './documentary';
import { LUCIO_PATENTS } from './lucio_patents';
import { BIOGRAFIA_PAGES } from './biografia';
import { ARCHIVIO_STORICO_PAGES } from './archivio_storico';
import { FOUNDATION_METADATA } from './archive_full';
import { WP_ARTICLES, WP_CATEGORIES } from './wordpress_articles';
import { PAOLO_FALACE } from './paolo_falace';

// Slugify Italian title
export const slug = (s) =>
  s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_|_$/g, '')
    .slice(0, 80);

// Convert plain text with newlines to paragraphs
const paragraphs = (text) =>
  (text || '')
    .split(/\n\n+/)
    .map((p) => p.trim())
    .filter(Boolean);

// Book type labels
const bookTypeLabel = {
  art: 'Arte',
  philosophy: 'Filosofia',
  theory: 'Teoria',
  patent: 'Brevetto',
  science: 'Scienza'
};

// === Build article objects ===
const articles = [];

// 1) Main Foundation article
articles.push({
  id: 'fondazione_falace_aic',
  slug: 'fondazione_falace_aic',
  title: 'Fondazione Falace delle Attività Intellettive Creative',
  category: 'Istituzione',
  subtitle: 'Denominazione ufficiale: FONDAZIONE FALACE — AIC',
  infobox: {
    'Denominazione': FOUNDATION_METADATA.denomination_it,
    'Fondatore': FOUNDATION_METADATA.founder,
    'Codice ATECO': FOUNDATION_METADATA.ateco_code,
    'Ambito': FOUNDATION_METADATA.ateco_desc_it,
    'Contatto': FOUNDATION_METADATA.email
  },
  sections: [
    {
      heading: 'Introduzione',
      paragraphs: [
        "La Fondazione Falace delle Attività Intellettive Creative (AIC) è un progetto istituzionale ideato e diretto dal Dott. Luca Falace, avente per scopo la tutela, l'archiviazione logica, la sistematizzazione rigorosa e la diffusione globale del patrimonio scientifico, bibliografico e brevettuale dell'Ideatore.",
        "Il patrimonio raccolto comprende oltre 50 monografie, 250 opere d'arte, 41 invenzioni catalogate e 3 brevetti d'invenzione industriale, integrando ricerca antropologica, produzione artistica sperimentale, innovazione tecnologica e imprenditorialità."
      ]
    },
    {
      heading: 'Dipartimenti Istituzionali di Tutela',
      paragraphs: [
        Object.values(FOUNDATION_METADATA.legal_backing).join('\n• ')
      ],
      list: Object.values(FOUNDATION_METADATA.legal_backing)
    },
    {
      heading: 'Struttura del progetto',
      paragraphs: [
        'Il portale enciclopedico si articola in tre grandi aree: **Biblioteca** (catalogo delle 50 monografie), **Bibliografia** (documentazione scientifica, brevetti e riferimenti) e **Biografia** (percorsi personali e istituzionali).'
      ]
    }
  ],
  seeAlso: ['luca_falace', 'sincronismo_creativo', 'aic_sync', 'genius_om'],
  references: [
    'Deposito CERN Zenodo — DOI istituzionali permanenti',
    'ICCU / OPAC SBN — Registro Bibliotecario Nazionale',
    'MiC / MiBAC — Ministero della Cultura'
  ]
});

// 2) Biografia Luca Falace (main biography, from BIOGRAFIA_PAGES)
articles.push({
  id: 'luca_falace',
  slug: 'luca_falace',
  title: 'Luca Falace',
  category: 'Biografia',
  subtitle: 'Ricercatore indipendente, storico dell\'arte, docente, inventore e imprenditore',
  infobox: {
    'Titolo': 'Dottore Magistrale',
    'Professione': 'Ricercatore indipendente',
    'Codice ATECO': '72.2',
    'Formazione': 'Laurea in Conservazione dei Beni Culturali',
    'Ruolo': 'Presidente Onorario Fondazione AIC',
    'Anni attività': '2005 – presente'
  },
  sections: BIOGRAFIA_PAGES.map((p) => ({
    heading: `Pagina ${p.pageNumber}`,
    paragraphs: paragraphs(p.content)
  })),
  seeAlso: [
    'fondazione_falace_aic',
    'sincronismo_creativo',
    'lucio_falace',
    'paolo_falace',
    'aic_sync',
    'genius_om',
    'opera_celeste'
  ],
  references: [
    'CERN Zenodo — DOI 10.5281/zenodo.17080308',
    'OPAC SBN — Catalogo Bibliotecario Nazionale',
    'UIBM — Ufficio Italiano Brevetti e Marchi'
  ]
});

// 3) Lucio Falace (father, inventor)
articles.push({
  id: 'lucio_falace',
  slug: 'lucio_falace',
  title: 'Lucio Falace',
  category: 'Biografia',
  subtitle: INVENTORS_TRADITION.generation1.legacy.slice(0, 140) + '...',
  infobox: {
    'Nome': INVENTORS_TRADITION.generation1.name,
    'Relazione familiare': INVENTORS_TRADITION.generation1.relation,
    'Attività': 'Scienziato, inventore',
    'Brevetti depositati': `${LUCIO_PATENTS.length} (Google Patents)`,
    'Ambito': 'Lampade a risparmio energetico'
  },
  sections: [
    {
      heading: 'Biografia',
      paragraphs: [INVENTORS_TRADITION.generation1.legacy]
    },
    {
      heading: 'Brevetti principali',
      paragraphs: [
        `Lucio Falace è titolare di ${LUCIO_PATENTS.length} brevetti industriali depositati principalmente negli anni 1990–2005 nel settore delle lampade a risparmio energetico e dispositivi elettro-ottici.`
      ],
      table: {
        headers: ['#', 'Numero', 'Titolo', 'Ufficio', 'Anno', 'Fonte'],
        rows: LUCIO_PATENTS.slice(0, 46).map((p) => [
          p.num,
          p.patentNum,
          p.title,
          p.office,
          p.year || '—',
          p.googleUrl ? `Google Patents: ${p.googleUrl}` : (p.wipoUrl || '—')
        ])
      }
    }
  ],
  seeAlso: ['luca_falace', 'fondazione_falace_aic', 'inventori_tradizione_familiare'],
  references: [
    'Google Patents — Inventor: Lucio Falace (https://patents.google.com/?inventor=Lucio+Falace)',
    'WIPO Patentscope (https://patentscope.wipo.int)',
    'UIBM — Ufficio Italiano Brevetti e Marchi (https://uibm.mise.gov.it/)'
  ]
});

// 3b) Paolo Falace — attore (biografia completa)
articles.push({
  id: 'paolo_falace',
  slug: 'paolo_falace',
  title: 'Paolo Falace',
  category: 'Biografia',
  subtitle: `${PAOLO_FALACE.role} (${PAOLO_FALACE.born}–${PAOLO_FALACE.died})`,
  infobox: {
    'Nome': PAOLO_FALACE.name,
    'Nascita': PAOLO_FALACE.born,
    'Morte': PAOLO_FALACE.died,
    'Professione': PAOLO_FALACE.role,
    'Relazione familiare': PAOLO_FALACE.relation,
    'Ultima interpretazione': "Acarnesi (Aristofane) — INDA Siracusa 1994"
  },
  image: { url: PAOLO_FALACE.photoUrl, caption: PAOLO_FALACE.photoCaption },
  sections: [
    { heading: 'Profilo biografico e artistico', paragraphs: paragraphs(PAOLO_FALACE.profile) },
    {
      heading: 'I. Formazione e attività teatrale — Prosa Rai',
      paragraphs: ["Partecipazione documentata negli archivi storici Rai Teche per oltre due decenni di prosa televisiva."],
      table: {
        headers: ['Periodo', 'Titolo', 'Ruolo / Note', 'Fonte'],
        rows: PAOLO_FALACE.teatroRai.map((t) => [
          t.period,
          t.title + (t.director ? ` — regia di ${t.director}` : ''),
          [t.role, t.airDate, t.cast, t.castNotes].filter(Boolean).join(' · '),
          `${t.source}: ${t.url}`
        ])
      }
    },
    {
      heading: 'II. Sceneggiati, fiction e film TV — Filmografia televisiva completa',
      paragraphs: ["Filmografia televisiva documentata dagli anni Sessanta agli anni Novanta."],
      table: {
        headers: ['Anno', 'Titolo', 'Regia / Ruolo / Note', 'Fonte'],
        rows: PAOLO_FALACE.filmografiaTV.map((f) => [
          f.year,
          f.title,
          [f.director ? `regia di ${f.director}` : '', f.role ? `ruolo: ${f.role}` : '', f.note].filter(Boolean).join(' · '),
          f.url || '—'
        ])
      }
    },
    {
      heading: 'III. Filmografia cinematografica',
      paragraphs: [],
      table: {
        headers: ['Anno', 'Titolo', 'Regia / Ruolo / Note', 'Fonte'],
        rows: PAOLO_FALACE.filmografiaCinema.map((f) => [
          f.year,
          f.title,
          [f.director ? `regia di ${f.director}` : '', f.role ? `ruolo: ${f.role}` : '', f.note].filter(Boolean).join(' · '),
          f.url || '—'
        ])
      }
    },
    {
      heading: 'IV. Teatro classico — INDA Siracusa 1994 (Acarnesi di Aristofane)',
      paragraphs: [
        PAOLO_FALACE.indaSiracusa1994.context,
        `Ruolo: ${PAOLO_FALACE.indaSiracusa1994.role} — regia di ${PAOLO_FALACE.indaSiracusa1994.director}. Musiche di ${PAOLO_FALACE.indaSiracusa1994.music}, scene e costumi di ${PAOLO_FALACE.indaSiracusa1994.scenography}.`,
        `Cast: ${PAOLO_FALACE.indaSiracusa1994.cast}.`
      ],
      list: PAOLO_FALACE.indaSiracusa1994.sources.map((s) => `${s.label}: ${s.url}`)
    },
    {
      heading: 'V. Fonti e riferimenti istituzionali',
      paragraphs: ["Profili biografici, database cinematografici nazionali e archivi storici Rai Teche:"],
      list: PAOLO_FALACE.fontiPrincipali.map((s) => `${s.label}: ${s.url}`)
    }
  ],
  seeAlso: ['luca_falace', 'lucio_falace', 'fondazione_falace_aic', 'inventori_tradizione_familiare'],
  references: PAOLO_FALACE.fontiPrincipali.map((s) => `${s.label} — ${s.url}`)
});

// 4) Sincronismo Creativo (main theory)
articles.push({
  id: 'sincronismo_creativo',
  slug: 'sincronismo_creativo',
  title: 'Sincronismo Creativo',
  category: 'Teoria',
  subtitle: 'Teoria degli eventi paralleli — Modello AIC-EC-HZ',
  infobox: {
    'Autore': 'Dott. Luca Falace',
    'Anno': '2005 – 2026',
    'Deposito': 'SIAE OLAF (2005)',
    'DOI Zenodo': '10.5281/zenodo.17080308',
    'Livelli sincronicità': '9'
  },
  sections: [
    {
      heading: 'Introduzione',
      paragraphs: [
        "Il Sincronismo Creativo è una teoria degli eventi paralleli sviluppata dal Dott. Luca Falace a partire dal 2005 e formalizzata scientificamente tra il 2025 e il 2026 nella cosiddetta Trilogia Scientifica depositata presso CERN Zenodo con DOI permanente.",
        "La teoria classifica in 9 livelli la convergenza tra risonanze biologiche (EEG, HRV), stati creativi e fenomeni fisici, unificando le frequenze quantistiche microscopiche con le bio-frequenze umane in un unico continuum hertziano."
      ]
    },
    {
      heading: 'I Nove Livelli della Sincronicità',
      paragraphs: [],
      table: {
        headers: ['Livello', 'Denominazione', 'Descrizione', 'Analogo scientifico'],
        rows: SYNC_LEVELS.map((l) => [
          l.level,
          l.titleIt,
          l.descriptionIt,
          l.scientificAnalogIt
        ])
      }
    },
    {
      heading: 'Modelli teorici comparati',
      paragraphs: [
        'La teoria si inserisce in una tradizione di modelli fisici e teorici, offrendo una sintesi contemporanea:'
      ],
      table: {
        headers: ['Autore', 'Teoria', 'Periodo', 'Sintesi'],
        rows: COMPARATIVE_MODELS.map((m) => [m.author, m.theory, m.period, m.summary])
      }
    },
    {
      heading: 'Risposta scientifica al barione Ξcc⁺ (CERN LHCb, 2026)',
      paragraphs: [
        LHCB_RESPONSE_PAPER.context,
        `Ipotesi principale: ${LHCB_RESPONSE_PAPER.keyHypothesis}`,
        `Implicazioni: ${LHCB_RESPONSE_PAPER.implications}`
      ]
    }
  ],
  seeAlso: SYNC_LEVELS.map((l) => `sync_level_${l.level}`).concat([
    'luca_falace',
    'aic_sync',
    'opera_celeste'
  ]),
  references: [
    'Zenodo DOI 10.5281/zenodo.17080308',
    'Zenodo DOI 10.5281/zenodo.17041593',
    'Zenodo DOI 10.5281/zenodo.20414984'
  ]
});

// 5) One article per sync level
SYNC_LEVELS.forEach((l) => {
  articles.push({
    id: `sync_level_${l.level}`,
    slug: `sincronicita_livello_${l.level}_${slug(l.titleIt)}`,
    title: `Livello ${l.level} — ${l.titleIt}`,
    category: 'Teoria',
    subtitle: l.descriptionIt,
    infobox: {
      'Livello': l.level,
      'Denominazione': l.titleIt,
      'Titolo inglese': l.titleEn,
      'Frequenze': l.experimentalBriefIt.split('.')[0]
    },
    sections: [
      { heading: 'Descrizione', paragraphs: [l.descriptionIt] },
      { heading: 'Protocollo sperimentale', paragraphs: [l.experimentalBriefIt] },
      { heading: 'Analogo scientifico', paragraphs: [l.scientificAnalogIt] },
      { heading: 'English version', paragraphs: [l.descriptionEn, l.experimentalBriefEn] }
    ],
    seeAlso: ['sincronismo_creativo', 'luca_falace'],
    references: ['Zenodo — Teoria del Campo Unificato AIC-EC-HZ']
  });
});

// 6) One article per book (50)
BOOKS.forEach((b) => {
  const info = {
    Titolo: b.title.replace(/^\d+\.\s*/, ''),
    Autore: 'Luca Falace',
    Anno: b.year,
    Editore: b.publisher,
    Tipologia: bookTypeLabel[b.type] || b.type
  };
  if (b.isbn) info.ISBN = b.isbn;
  if (b.asin) info.ASIN = b.asin;
  if (b.doi) info.DOI = b.doi;
  if (b.pages) info.Pagine = b.pages;

  articles.push({
    id: b.id,
    slug: slug(b.title),
    title: b.title.replace(/^\d+\.\s*/, ''),
    category: 'Libro',
    subtitle: `${b.publisher} (${b.year}) — ${bookTypeLabel[b.type] || b.type}`,
    infobox: info,
    sections: [
      { heading: 'Descrizione', paragraphs: [b.description] },
      ...(b.link
        ? [{ heading: 'Collegamento esterno', paragraphs: [b.link], externalLink: b.link }]
        : [])
    ],
    seeAlso: ['luca_falace', 'sincronismo_creativo', 'fondazione_falace_aic'],
    references: [
      b.isbn ? `ISBN: ${b.isbn}` : null,
      b.asin ? `ASIN: ${b.asin}` : null,
      b.doi ? `DOI: ${b.doi}` : null,
      'Catalogo OPAC SBN — ICCU'
    ].filter(Boolean)
  });
});

// 7) One article per invention (main patents + selected)
INVENTIONS.forEach((inv) => {
  articles.push({
    id: inv.id,
    slug: slug(inv.title),
    title: inv.title,
    category: 'Invenzione',
    subtitle: `${inv.year} — ${inv.status === 'registered' ? 'Brevetto registrato' : inv.status === 'donated' ? 'Brevetto donato' : 'Brevetto depositato'}`,
    infobox: {
      Titolo: inv.title,
      Anno: inv.year,
      'Numero brevetto': inv.patentNum || '—',
      Stato: inv.status,
      Inventore: 'Luca Falace'
    },
    sections: [
      { heading: 'Descrizione', paragraphs: [inv.description] },
      { heading: 'Dettagli tecnici', paragraphs: [inv.details] },
      ...(inv.googlePatentsLink
        ? [
            {
              heading: 'Google Patents',
              paragraphs: [inv.googlePatentsLink],
              externalLink: inv.googlePatentsLink
            }
          ]
        : [])
    ],
    seeAlso: ['luca_falace', 'fondazione_falace_aic', 'lucio_falace', 'genius_om'],
    references: ['UIBM — Ufficio Italiano Brevetti e Marchi', 'Google Patents']
  });
});

// Add GeniusOm as separate main article + AIC-SYNC alias
articles.push({
  id: 'genius_om',
  slug: 'genius_om',
  title: 'GeniusOm — Compattatore Multiplo Pneumatico Zero Waste',
  category: 'Invenzione',
  subtitle: 'Brevetto ITNA20130029A1 (2013) · Pubblicato 23/11/2014',
  infobox: {
    'Denominazione': 'GeniusOm',
    'Numero brevetto': 'ITNA20130029A1',
    'Anno deposito': 2013,
    'Data pubblicazione': '23/11/2014',
    'Riduzione volumetrica': 'fino al 90%',
    'Riconoscimenti': 'Premio Ecomondo 2014, Shark Tank Italia 2015',
    'Google Patents': 'https://patents.google.com/patent/ITNA20130029A1/en'
  },
  sections: [
    {
      heading: 'Sintesi',
      paragraphs: [
        "GeniusOm è un compattatore domestico ad alta efficienza per lo smaltimento ecologico intelligente dei rifiuti urbani differenziati, brevettato dal Dott. Luca Falace nel 2013 (Brevetto ITNA20130029A1, pubblicato il 23/11/2014).",
        "Consente la riduzione volumetrica fino al 90% dei rifiuti secchi e organici riciclabili a livello domestico grazie a filtri molecolari termodinamicamente equilibrati."
      ]
    },
    {
      heading: 'Riconoscimenti',
      paragraphs: [
        'Premio Ecomondo Rimini 2014 con Adesione del Presidente della Repubblica; servizio televisivo esclusivo su RAI 2 (I Fatti Vostri, 11 aprile 2017); offerta di €250.000 confermata su Shark Tank Italia (Italia 1, 4 giugno 2015) dall\'investitore Ing. Fabio Cannavale.'
      ]
    },
    {
      heading: 'Collegamento ufficiale',
      paragraphs: ['https://patents.google.com/patent/ITNA20130029A1/en'],
      externalLink: 'https://patents.google.com/patent/ITNA20130029A1/en'
    }
  ],
  seeAlso: ['luca_falace', 'shark_tank_italia', 'i_fatti_vostri', 'premio_ecomondo'],
  references: [
    'Google Patents — ITNA20130029A1 (https://patents.google.com/patent/ITNA20130029A1/en)',
    'UIBM — Ufficio Italiano Brevetti e Marchi',
    'Wikipedia — Shark Tank Italia (https://it.wikipedia.org/wiki/Shark_Tank_Italia)'
  ]
});

articles.push({
  id: 'aic_sync',
  slug: 'aic_sync',
  title: 'AIC-SYNC© — Sistema per Sincronicità Indotte',
  category: 'Invenzione',
  subtitle: 'Brevetto UIBM-2024-AIC01 · DOI 10.5281/zenodo.17793651',
  infobox: {
    'Denominazione': 'AIC-SYNC©',
    'Numero brevetto': 'UIBM-2024-AIC01',
    'Anno': 2024,
    'DOI Zenodo': '10.5281/zenodo.17793651',
    'Tecnologie': 'EEG multicanale, HRV, feedback bio-adattivi'
  },
  sections: [
    {
      heading: 'Descrizione',
      paragraphs: [
        "Primo sistema bio-informatico integrato al mondo finalizzato al monitoraggio e all'induzione attiva di picchi creativi e convergenze sincronicistiche.",
        "Integra un lettore EEG multicanale portatile con sensori di variabilità cardiaca (HRV) e una matrice di feedback neuro-funzionali bio-adattivi: modulazioni acustiche binaurali, impulsi luminosi stroboscopici sintonizzati sulle onde Alpha e Theta, e micro-vibrazioni aptiche."
      ]
    }
  ],
  seeAlso: ['luca_falace', 'sincronismo_creativo', 'fondazione_falace_aic'],
  references: ['CERN Zenodo DOI 10.5281/zenodo.17793651']
});

// 8) One article per artwork
ARTWORKS.forEach((a) => {
  articles.push({
    id: a.id,
    slug: slug(a.title),
    title: a.title,
    category: "Opera d'arte",
    subtitle: `${a.category} — ${a.venue} (${a.year})`,
    infobox: {
      Titolo: a.title,
      Anno: a.year,
      Categoria: a.category,
      Sede: a.venue,
      Autore: 'Luca Falace'
    },
    sections: [{ heading: 'Descrizione', paragraphs: [a.description] }],
    seeAlso: ['luca_falace', 'sincronismo_creativo', 'fondazione_falace_aic'],
    references: ['MAXXI — Catalogazione contemporanea', 'MiC / MiBAC — Registro diritto d\'autore']
  });
});

// 9) Institutional Venues
INSTITUTIONAL_VENUES.forEach((v) => {
  articles.push({
    id: slug(v.name),
    slug: slug(v.name),
    title: v.name,
    category: 'Istituzione',
    subtitle: 'Sede istituzionale collegata all\'attività della Fondazione',
    infobox: { Nome: v.name, Ambito: 'Sede espositiva / scientifica' },
    sections: [{ heading: 'Descrizione', paragraphs: [v.description] }],
    seeAlso: ['luca_falace', 'fondazione_falace_aic'],
    references: []
  });
});

// 10) Exhibitions
EXHIBITIONS.forEach((e) => {
  const sections = [
    { heading: 'Introduzione', paragraphs: paragraphs(e.introIt) }
  ];
  if (e.pressTextIt) {
    sections.push({
      heading: `Rassegna stampa — ${e.pressSourceIt || 'Stampa'}: "${e.pressTitleIt || ''}"`,
      paragraphs: paragraphs(e.pressTextIt)
    });
  }
  if (e.aicCurationIt) {
    sections.push({ heading: 'Curatela e Sperimentazione AIC', paragraphs: paragraphs(e.aicCurationIt) });
  }
  if (e.allestimentoEmphasisIt) {
    sections.push({ heading: 'Allestimento', paragraphs: paragraphs(e.allestimentoEmphasisIt) });
  }
  if (e.manuscriptsTextIt) {
    sections.push({
      heading: e.manuscriptsTitleIt || 'Manoscritti',
      paragraphs: paragraphs(e.manuscriptsTextIt)
    });
  }
  if (e.albums && e.albums.length) {
    sections.push({
      heading: 'Album fotografici',
      paragraphs: [
        `Documentazione fotografica ufficiale dell'evento (${e.albums.length} album, ${e.albums.reduce(
          (acc, a) => acc + (a.photosCount || 0),
          0
        )} scatti complessivi):`
      ],
      table: {
        headers: ['Album', 'Contenuto', 'Foto', 'Link'],
        rows: e.albums.map((a) => [a.titleIt, a.contentIt, a.photosCount, a.link])
      }
    });
  }
  articles.push({
    id: e.id,
    slug: slug(e.titleIt),
    title: e.titleIt,
    category: 'Mostra',
    subtitle: `${e.datesIt} — ${e.venueIt}`,
    infobox: {
      Titolo: e.titleIt,
      Date: e.datesIt,
      Sede: e.venueIt,
      Anno: e.year,
      Patrocinio: e.patronageIt || '—',
      'Fonte stampa': e.pressSourceIt || '—'
    },
    sections,
    seeAlso: ['luca_falace', 'sincronismo_creativo', 'fondazione_falace_aic'],
    references: [
      e.validationLink ? `${e.validationTitleIt || 'Fonte'}: ${e.validationLink}` : null,
      e.copyrightNoteIt
    ].filter(Boolean)
  });
});

// 11) Documentary episodes
DOCUMENTARY_SERIES.forEach((d) => {
  articles.push({
    id: `doc_${d.episodeNum}`,
    slug: slug(d.title),
    title: d.title,
    category: 'Documentario',
    subtitle: d.topics.join(' · '),
    infobox: {
      Titolo: d.title,
      Anno: d.year,
      'Argomenti principali': d.topics.join(', '),
      'Link YouTube': d.youtubeUrl || '—'
    },
    sections: [
      { heading: 'Descrizione', paragraphs: [d.description] },
      ...(d.youtubeUrl
        ? [{ heading: 'Video ufficiale', paragraphs: [d.youtubeUrl], externalLink: d.youtubeUrl }]
        : []),
      ...(d.wikipediaUrl
        ? [
            {
              heading: 'Riferimento Wikipedia',
              paragraphs: [d.wikipediaUrl],
              externalLink: d.wikipediaUrl
            }
          ]
        : [])
    ],
    seeAlso: ['luca_falace', 'genius_om', 'fondazione_falace_aic'],
    references: [d.wikipediaUrl].filter(Boolean)
  });
});

// 12) Lucio Falace individual patents (all 46)
LUCIO_PATENTS.forEach((p) => {
  const id = `lucio_patent_${p.num}`;
  articles.push({
    id,
    slug: slug(`brevetto_${p.patentNum}_${p.title}`),
    title: `${p.patentNum} — ${p.title}`,
    category: 'Brevetto',
    subtitle: `Brevetto ${p.office} (${p.year || 's.d.'}) — Inventore: Lucio Falace`,
    infobox: {
      Numero: p.patentNum,
      Titolo: p.title,
      Ufficio: p.office,
      Anno: p.year || '—',
      Inventore: 'Lucio Falace'
    },
    sections: [
      {
        heading: 'Descrizione',
        paragraphs: [
          `Il brevetto ${p.patentNum} — "${p.title}" fa parte del corpus di ${LUCIO_PATENTS.length} brevetti industriali depositati da Lucio Falace, principalmente nel settore delle lampade a risparmio energetico e dei circuiti elettro-ottici. Il brevetto è stato registrato presso l'ufficio brevetti ${p.office} nel ${p.year || 'periodo non specificato'}.`
        ]
      },
      ...(p.googleUrl
        ? [{ heading: 'Google Patents', paragraphs: [p.googleUrl], externalLink: p.googleUrl }]
        : []),
      ...(p.wipoUrl
        ? [{ heading: 'WIPO Patentscope', paragraphs: [p.wipoUrl], externalLink: p.wipoUrl }]
        : [])
    ],
    seeAlso: ['lucio_falace', 'inventori_tradizione_familiare'],
    references: [
      `Google Patents — ${p.patentNum} (${p.googleUrl || 'ricerca manuale'})`,
      p.wipoUrl ? `WIPO Patentscope: ${p.wipoUrl}` : null
    ].filter(Boolean)
  });
});

// 13) Tradition
articles.push({
  id: 'inventori_tradizione_familiare',
  slug: 'inventori_tradizione_familiare',
  title: 'Tradizione familiare degli inventori Falace',
  category: 'Biografia',
  subtitle: 'Tre generazioni di inventori e imprenditori',
  infobox: {
    'Generazioni': 3,
    'Ambiti': 'Illuminotecnica, ecologia, bio-informatica',
    'Brevetti familiari': `${LUCIO_PATENTS.length + INVENTIONS.length}+`
  },
  sections: [
    {
      heading: `Prima generazione — ${INVENTORS_TRADITION.generation1.name}`,
      paragraphs: [INVENTORS_TRADITION.generation1.legacy]
    },
    {
      heading: `Seconda generazione — ${INVENTORS_TRADITION.generation2.name}`,
      paragraphs: [INVENTORS_TRADITION.generation2.legacy]
    }
  ],
  seeAlso: ['luca_falace', 'lucio_falace', 'genius_om', 'aic_sync'],
  references: ['Google Patents — Inventor: Falace']
});

// 14) Archivio Storico (multi-section)
articles.push({
  id: 'archivio_storico',
  slug: 'archivio_storico',
  title: 'Archivio Storico della Fondazione Falace AIC',
  category: 'Documento',
  subtitle: 'Documentazione istituzionale integrale (2005–2025)',
  infobox: {
    'Periodo': '2005–2025',
    'Pagine documento': ARCHIVIO_STORICO_PAGES.length,
    'Autore': 'Dott. Luca Falace',
    'Ambito': 'Deposito istituzionale integrale'
  },
  sections: ARCHIVIO_STORICO_PAGES.map((p) => ({
    heading: `Pagina ${p.pageNumber}`,
    paragraphs: paragraphs(p.content)
  })),
  seeAlso: ['fondazione_falace_aic', 'luca_falace'],
  references: ['ICCU / OPAC SBN', 'MiC / MiBAC', 'CERN Zenodo']
});

// Additional context articles
articles.push({
  id: 'opera_celeste',
  slug: 'opera_celeste',
  title: "L'Opera Celeste",
  category: 'Concetto',
  subtitle: 'Romanzo alchemico-filosofico (2005) — Matrice teorica del Sincronismo Creativo',
  infobox: {
    'Prima edizione': '2005, O.R.O. Edizioni',
    'ISBN prima ed.': '88-901926-0-7',
    'Ristampe': 'Amazon 2012, Iemme 2013',
    'Ambito': 'Alchimia, filosofia, teoria'
  },
  sections: [
    {
      heading: 'Sintesi',
      paragraphs: [
        "L'Opera Celeste è il romanzo alchemico-filosofico d'esordio del Dott. Luca Falace, pubblicato nel 2005 da O.R.O. Edizioni. Il testo attesta la paternità della Teoria del Sincronismo Creativo, di cui costituisce la matrice narrativa e concettuale.",
        "Il romanzo è stato oggetto di più edizioni: seconda ristampa Gruppo Editoriale L'Espresso (2010), edizione digitale Amazon Kindle (2012, ASIN B008KA6R0O), terza edizione ampliata Iemme Edizioni (2013, ISBN 978-88-97776-08-6)."
      ]
    }
  ],
  seeAlso: ['luca_falace', 'sincronismo_creativo', 'book-celeste', 'book-celeste-3ed'],
  references: ["Amazon ASIN B008KA6R0O", "ISBN 978-88-97776-08-6"]
});

articles.push({
  id: 'shark_tank_italia',
  slug: 'shark_tank_italia',
  title: 'Shark Tank Italia (partecipazione GeniusOm 2015)',
  category: 'Evento',
  subtitle: 'Italia 1 — Mediaset · 4 giugno 2015',
  infobox: {
    'Programma': 'Shark Tank Italia',
    'Emittente': 'Italia 1 (Mediaset)',
    'Data': '4 giugno 2015',
    'Investimento': '€250.000',
    'Investitore': 'Ing. Fabio Cannavale',
    'Quota': '70%'
  },
  sections: [
    {
      heading: 'Descrizione',
      paragraphs: [
        "Il 4 giugno 2015 il Dott. Luca Falace partecipa in prima serata su Italia 1 al programma televisivo Shark Tank Italia, presentando il progetto d'impresa ecologico GeniusOm. La trattativa d'investimento si è conclusa con successo per un valore di €250.000 per il 70% delle quote della start-up, con l'investitore Ing. Fabio Cannavale."
      ]
    }
  ],
  seeAlso: ['genius_om', 'luca_falace', 'i_fatti_vostri'],
  references: ['Wikipedia — Shark Tank Italia']
});

articles.push({
  id: 'i_fatti_vostri',
  slug: 'i_fatti_vostri',
  title: 'I Fatti Vostri (partecipazione GeniusOm 2017)',
  category: 'Evento',
  subtitle: 'Rai 2 · 11 aprile 2017',
  infobox: {
    'Programma': 'I Fatti Vostri',
    'Emittente': 'Rai 2',
    'Data': '11 aprile 2017',
    'Conduttore': 'Giancarlo Magalli'
  },
  sections: [
    {
      heading: 'Descrizione',
      paragraphs: [
        "L'11 aprile 2017 il Dott. Luca Falace partecipa al programma televisivo I Fatti Vostri (Rai 2) condotto da Giancarlo Magalli, presentando in prima nazionale il brevetto GeniusOm per l'approvazione del Ministero dei Brevetti Italiani."
      ]
    }
  ],
  seeAlso: ['genius_om', 'luca_falace'],
  references: []
});

articles.push({
  id: 'premio_ecomondo',
  slug: 'premio_ecomondo_2014',
  title: 'Premio Ecomondo 2014',
  category: 'Evento',
  subtitle: 'Rimini · 5-8 novembre 2014 · Green Economy',
  infobox: {
    'Manifestazione': 'Ecomondo 2014',
    'Sede': 'Rimini',
    'Riconoscimento': 'Migliore invenzione e brevetto Green Economy',
    'Adesione': 'Presidente della Repubblica Italiana',
    'Brevetto premiato': 'ITNA20130029A1 (GeniusOm)'
  },
  sections: [
    {
      heading: 'Descrizione',
      paragraphs: [
        "Il Dott. Luca Falace riceve nel novembre 2014 il Premio Ecomondo per la migliore invenzione e brevetto nel settore della Green Economy, presso la Fiera Internazionale di Rimini (5-8 novembre 2014), con adesione del Presidente della Repubblica Italiana. Il premio è conferito al brevetto ITNA20130029A1 di GeniusOm — Compattatore Domestico Zero Waste."
      ]
    }
  ],
  seeAlso: ['genius_om', 'luca_falace'],
  references: []
});

// Comparative models articles (4)
COMPARATIVE_MODELS.forEach((m) => {
  articles.push({
    id: slug(m.author + '_' + m.theory),
    slug: slug(m.author + '_' + m.theory),
    title: `${m.theory} (${m.author})`,
    category: 'Teoria',
    subtitle: `${m.period} — Modello teorico comparato`,
    infobox: {
      Autore: m.author,
      Teoria: m.theory,
      Periodo: m.period
    },
    sections: [
      { heading: 'Sintesi', paragraphs: [m.summary] },
      { heading: 'Rilevanza per il Sincronismo Creativo', paragraphs: [m.relevance] }
    ],
    seeAlso: ['sincronismo_creativo', 'luca_falace'],
    references: []
  });
});

// 15) WordPress historical archive posts (121 voices imported from lucafalace.altervista.org)
WP_ARTICLES.forEach((a) => articles.push(a));

// Category map
export const CATEGORIES = [
  'Istituzione',
  'Biografia',
  'Libro',
  'Invenzione',
  'Brevetto',
  "Opera d'arte",
  'Mostra',
  'Documentario',
  'Teoria',
  'Evento',
  'Concetto',
  'Documento',
  ...WP_CATEGORIES
];

export const ARTICLES = articles;
export const ARTICLES_BY_ID = Object.fromEntries(articles.map((a) => [a.id, a]));
export const ARTICLES_BY_SLUG = Object.fromEntries(articles.map((a) => [a.slug, a]));

// Featured selection for main page
export const FEATURED = [
  'fondazione_falace_aic',
  'luca_falace',
  'paolo_falace',
  'lucio_falace',
  'sincronismo_creativo',
  'genius_om',
  'aic_sync',
  'opera_celeste'
];

export const TOTAL_COUNT = articles.length;
