

export const INVENTIONS = [
  {
    id: 'patent-1',
    num: 1,
    title: 'AIC-SYNC© — Sistema Hardware e Software per Sincronicità Indotte',
    year: 2024,
    patentNum: 'UIBM-2024-AIC01',
    status: 'registered',
    description: 'Primo sistema bio-informatico integrato al mondo finalizzato al monitoraggio e all\'induzione attiva di picchi creativi e convergenze sincronicistiche.',
    details: 'Questo sistema integra un lettore EEG multicanale portatile con sensori di variabilità cardiaca (HRV) e una matrice di feedback neuro-funzionali bio-adattivi (modulazioni acustiche binaurali, impulsi luminosi stroboscopici sintonizzati sulle onde Alpha e Theta, e micro-vibrazioni aptiche). Il software mappa lo stato cognitivo dell\'operatore creativo e sintonizza l\'ambiente per provocare risonanze ottimali di insight e insight operativi, ideati sull\'esperimento scientifico del 2014 condotto su 200 soggetti.',
  },
  {
    id: 'patent-2',
    num: 2,
    title: 'GeniusOm — Compattatore Multiplo Pneumatico per Rifiuti Urbani (Zero Waste)',
    year: 2013,
    patentNum: 'ITNA20130029A1',
    status: 'registered',
    description: 'Macchine compattatrici multiple, per rifiuti domestici e pubblici urbani, con sterilizzazione automatica.',
    googlePatentsLink: 'https://patents.google.com/patent/ITNA20130029A1/en',
    publicationDate: '23/11/2014',
    details: 'Brevetto di ingegneria sostenibile d\'eccellenza (inventore Luca Falace). Consente la riduzione volumetrica fino al 90% dei rifiuti secchi e organici riciclabili a livello domestico, senza emissione di odori grazie a filtri molecolari termodinamicamente equilibrati. Ha ottenuto il Premio Ecomondo Rimini 2014 con Adesione del Presidente della Repubblica, un servizio esclusivo su RAI 2 (I Fatti Vostri, 2017) e offerta di €250.000 a Shark Tank Italia (2015).',
  },
  {
    id: 'patent-3',
    num: 3,
    title: 'Eco-Tuta Integrale Termodinamica Climatizzata — Esoscheletro Bioclimatico Indossabile',
    year: 2018,
    patentNum: 'IT201800003616U1',
    status: 'donated',
    description: 'Tuta integrale ecologica termodinamica climatizzata con doppio strato termodinamico ed esoscheletro bioclimatico indossabile.',
    googlePatentsLink: 'https://patents.google.com/patent/IT201800003616U1/en',
    publicationDate: '24/04/2020',
    details: 'Tuta termodinamica auto-alimentata provvista di micro-canali conduttivi idraulici volti alla stabilizzazione termica interna contro la calura e il gelo. Progettata per resistere a temperature limite, è stata donata formalmente e volontariamente dal Dott. Luca Falace al Movimento Europeo Italia per scopi umanitari durante la pandemia SARS-CoV-2 (COVID-19) a supporto del personale sul campo.',
  },
  // selected other inventions from the 41 registered catalogue
  {
    id: 'inv-4',
    num: 4,
    title: 'Aero-Massaggiatore Meccanico a Campana di Risonanza',
    year: 2005,
    status: 'registered',
    description: 'Dispositivo pneumatico micro-vibratorio indirizzato allo stimolo locale dei tessuti tramite frequenze simpatiche.',
    details: 'Sfrutta micro-vortici di pressione oscillanti per indurre risonanza muscolare a frequenza programmabile (8Hz - 24Hz), simulando stimolazioni circolatorie profonde.'
  },
  {
    id: 'inv-5',
    num: 5,
    title: 'L.E.T.S.I.S. Robotics Platform - Sistema di Giunti Simpatetici',
    year: 2015,
    status: 'registered',
    description: 'Architettura robotica basata su giunzioni risonanti sintonizzate magneticamente.',
    details: 'Permette il coordinamento di micro-attuatori meccanici minimizzando la dispersione di forza dissipata in calore, tramite accoppiamento vibratorio auto-sintonizzante.'
  },
  {
    id: 'inv-6',
    num: 6,
    title: 'Filtro Ottico Flussimetrico a Cristalli Sincronizzati',
    year: 2020,
    status: 'registered',
    description: 'Sensore passivo per l\'analisi dello spettro elettromagnetico di micro-sorgenti in tempo reale.',
    details: 'Sviluppato per rilevare impercettibili fluttuazioni di sorgenti coerenti di luce in relazione alle alterazioni del coefficiente di rifrazione aereo.'
  },
  {
    id: 'inv-7',
    num: 7,
    title: 'Generatore di Frequenze Carrier a Trasmissione Ossea',
    year: 2025,
    status: 'deposited',
    description: 'Trasmettitore hertziano portatile provvisto di cuffia a conduzione ossea operante su carrier a 432Hz.',
    details: 'Progettato per iniettare micro-onde acustiche di sincronismo neurobiologico a supporto dello studio e del superamento di blocchi ideativi creativi.'
  }
];

export const INVENTORS_TRADITION = {
  generation1: {
    name: 'Lucio Falace',
    relation: 'Padre',
    legacy: 'Scienziato di rilievo e inventore primario a livello internazionale delle lampade a risparmio energetico commerciali (deposito 1995, con decine di brevetti regolarmente registrati e visibili su Google Patents). Ha ispirato l\'approccio di ricerca empirica e ingegneristica dell\'intero asse familiare.'
  },
  generation2: {
    name: 'Dott. Luca Falace',
    relation: 'Autore / Ricercatore',
    legacy: 'Sviluppatore dei 3 brevetti principali contemporanei, 41 invenzioni regolate MiBAC, e teorizzatore del modello di Campo Unificato sincronetico AIC-EC-HZ, unendo la propensione brevettuale di famiglia al rigore d\'arte e fisica quantitativa.'
  }
};
