

export const ARTWORKS = [
  {
    id: 'art-1',
    title: 'Diacronia Figurativa #12',
    year: 2012,
    category: 'pittura',
    venue: 'Museo di Capodimonte / PAN',
    description: 'Sperimentazione segnica estesa su grande formato, focalizzata sulla trasposizione di archetipi mitologici tradizionali in andamenti vettoriali geometrici.',
    associatedAlbumId: 'album-2012-capodimonte'
  },
  {
    id: 'art-2',
    title: 'Oltre l\'Interpretazione di Copenaghen',
    year: 2014,
    category: 'videoarte',
    venue: 'Città della Scienza / MAV (Archivio)',
    description: 'Installazione sinestetica e video-esperimento che mette in risonanza gli stati mentali degli osservatori con fluttuazioni luminose simulate.',
    associatedAlbumId: 'album-2014-citta-scienza'
  },
  {
    id: 'art-3',
    title: 'Esperimento EEG dei 200 Soggetti: Il Cervello Collettivo',
    year: 2014,
    category: 'ricerca',
    venue: 'Città della Scienza (Moon Party)',
    description: 'Rilevamento simultaneo e monitoraggio delle risonanze empatiche e di risincronizzazione ritmica tra coppie di soggetti durante performance sonore.',
    associatedAlbumId: 'album-2014-citta-scienza'
  },
  {
    id: 'art-4',
    title: 'Codici Alchemici: L\'Opera Celeste',
    year: 2005,
    category: 'installazione',
    venue: 'Centro Culturale Arte e Scienza / MAXXI (Archivio)',
    description: 'Presentazione plastica e interattiva dei 22 glifi legati allo studio dell\'alchimia rinascimentale vissuta come processo psicologico sincronico.',
    associatedAlbumId: 'album-1-general'
  },
  {
    id: 'art-5',
    title: 'Sincronismo Segnico Assoluto',
    year: 2007,
    category: 'pittura',
    venue: 'PAN - Palazzo delle Arti',
    description: 'Dipinto a tempera alchemica su tela grezza. Il dipinto è stato concepito durante un picco di sincronicità oggettiva riscontrata a livello familiare.',
    associatedAlbumId: 'album-3-perf-c'
  },
  {
    id: 'art-6',
    title: 'La Geometria del Caso Significativo',
    year: 2011,
    category: 'videoarte',
    venue: 'MAXXI - Museo Nazionale delle Arti del XXI Secolo',
    description: 'Proiezione quadrifonica di segnale isocronico a 432Hz sovrapposto a sequenze video accelerate di evoluzioni stellari ed atomiche.',
    associatedAlbumId: 'album-6-mosaic'
  },
  {
    id: 'art-7',
    title: 'Il Tempio delle Attività Intellettive',
    year: 2013,
    category: 'installazione',
    venue: 'Città della Scienza (Ricostruzione post-incendio)',
    description: 'Installazione sferica in rame ed ottone progettata per la purificazione degli spazi d\'ascolto e la riduzione spaziale delle interferenze RF ambientali.',
    associatedAlbumId: 'album-4-backstage'
  }
];

export const INSTITUTIONAL_VENUES = [
  {
    name: 'Museo di Capodimonte',
    description: 'Sede della memorabile performance live notturna del 28 settembre 2012, in cui è stata data la prima dimostrazione pratica e fenomenologica delle Attività Intellettive Creative (AIC).'
  },
  {
    name: 'Complesso Monumentale di San Severo al Pendino',
    description: 'La storica chiesa barocca di via Duomo ha ospitato la grande rassegna personale "Diacronia Figurativa e Sincronismo Creativo" ospitata sotto il Patrocinio Comunale nell\'aprile 2013.'
  },
  {
    name: 'Città della Scienza',
    description: 'Sede nel 2014 delle mostre interattive e del rigoroso test biometrico "Connection" condotto su oltre 150 coppie tramite speciali cuffie e caschetti di monitoraggio EEG delle onde cerebrali.'
  }
];
