// WordPress posts (Archivio Storico 1996-2024) — importati dai file HTML del portale
// lucafalace.altervista.org e riorganizzati come voci enciclopediche integrali.
// Nessuna sintesi: preservati blocchi sequenziali (titoli, paragrafi, immagini, elenchi, tabelle).
import posts from './wordpress_posts.json';

// Slugify Italian title
const slug = (s) =>
  s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_|_$/g, '')
    .slice(0, 80);

// Categorize based on title / tags keywords
function inferCategory(title, tags) {
  const bag = (title + ' ' + (tags || []).join(' ')).toUpperCase();
  if (/(LIBRI|LIBRO|BIBLIOTECA|ISBN|EDITORE|EDITRICE|PUBBLICAZIONE)/.test(bag)) return 'Archivio Storico — Libri & Pubblicazioni';
  if (/(BREVETT|INVENZIONE|GENIUSOM|GENIUS-OM|GENIUS OM|AIC-SYNC|PATENT|UIBM|WIPO)/.test(bag)) return 'Archivio Storico — Brevetti & Invenzioni';
  if (/(MOSTRA|ESPOSIZIONE|VIDEO-INSTALLAZIONE|VIDEO INSTALLAZIONE|OPERE|BIENNALE|GALLERIA)/.test(bag)) return 'Archivio Storico — Mostre & Opere';
  if (/(SHARK TANK|RAI|MEDIASET|MAGALLI|TV |TELEVISIONE|SKY )/.test(bag)) return 'Archivio Storico — Televisione & Media';
  if (/(ECOMONDO|CONFINDUSTRIA|PREMIO|PREMIAZIONE|MEDAGLIA|ONORIFICENZA)/.test(bag)) return 'Archivio Storico — Premi & Riconoscimenti';
  if (/(SINCRONISMO|TEORIA|LHCb|FISICA|QUANTIST)/.test(bag)) return 'Archivio Storico — Teoria & Scienza';
  if (/(BIOGRAFIA|LUCA FALACE|LUCIO FALACE|CURRICULUM|PAOLO FALACE)/.test(bag)) return 'Archivio Storico — Biografia';
  if (/(EVENTI|MUSEI|MUSEO|CONFERENZA|CONVEGNO|FIERA)/.test(bag)) return 'Archivio Storico — Eventi & Musei';
  return 'Archivio Storico — Documenti';
}

// HTML entities cleanup
function cleanTitle(t) {
  return (t || '')
    .replace(/&#x27;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&nbsp;/g, ' ')
    .replace(/&#8217;/g, "'")
    .replace(/&#8220;/g, '"')
    .replace(/&#8221;/g, '"')
    .replace(/&#8211;/g, '–')
    .replace(/&#8212;/g, '—')
    .replace(/&mdash;/g, '—')
    .replace(/&ndash;/g, '–')
    .trim();
}

// Convert rich sequential blocks into encyclopedia "sections".
// Strategy: each h2/h3 in the source starts a new sub-section; content between
// headings is collected as paragraphs / images / lists / tables.
function blocksToSections(blocks, meta) {
  const sections = [];
  let current = {
    heading: 'Descrizione integrale',
    paragraphs: [],
    images: [],
    imageCaptions: [],
    list: null,
    table: null,
    blocks: [],
  };

  const pushCurrent = () => {
    // include only if it has any content
    const hasContent =
      current.paragraphs.length ||
      current.images.length ||
      current.list ||
      current.table ||
      current.blocks.length;
    if (hasContent) sections.push(current);
  };

  for (const b of blocks) {
    if (b.type === 'heading' && (b.level === 2 || b.level === 3)) {
      pushCurrent();
      current = {
        heading: cleanTitle(b.text) || 'Sezione',
        paragraphs: [],
        images: [],
        imageCaptions: [],
        list: null,
        table: null,
        blocks: [],
      };
    } else if (b.type === 'paragraph') {
      const txt = cleanTitle(b.text);
      if (txt) {
        current.paragraphs.push(txt);
        current.blocks.push({ type: 'p', text: txt });
      }
    } else if (b.type === 'image') {
      current.images.push(b.src);
      current.imageCaptions.push(cleanTitle(b.caption) || '');
      current.blocks.push({ type: 'img', src: b.src, caption: cleanTitle(b.caption) || '' });
    } else if (b.type === 'list') {
      current.list = (current.list || []).concat(b.items.map(cleanTitle));
      current.blocks.push({ type: 'list', ordered: !!b.ordered, items: b.items.map(cleanTitle) });
    } else if (b.type === 'table') {
      // Best-effort: first row as headers
      const rows = b.rows.map((r) => r.map(cleanTitle));
      const headers = rows[0] || [];
      const body = rows.slice(1);
      current.table = { headers, rows: body };
      current.blocks.push({ type: 'table', headers, rows: body });
    } else if (b.type === 'video') {
      current.blocks.push({ type: 'video', src: b.src, caption: cleanTitle(b.caption) || '' });
    } else if (b.type === 'embed') {
      current.blocks.push({ type: 'embed', url: b.url, caption: cleanTitle(b.caption) || '' });
    } else if (b.type === 'hr') {
      current.blocks.push({ type: 'hr' });
    } else if (b.type === 'heading') {
      // h1/h4-h6 → keep as bold paragraph
      const txt = cleanTitle(b.text);
      if (txt) {
        current.paragraphs.push(txt);
        current.blocks.push({ type: 'p', text: txt, strong: true });
      }
    }
  }
  pushCurrent();

  // Ensure at least one section
  if (!sections.length) {
    sections.push({
      heading: 'Descrizione',
      paragraphs: [
        `Voce dell'Archivio Storico del Dott. Luca Falace (${meta.date || 's.d.'}). Documento ID ${meta.post_id}.`,
      ],
    });
  }

  // Append tags as an "Etichette" section
  if (meta.tags && meta.tags.length) {
    sections.push({
      heading: 'Etichette e parole-chiave',
      paragraphs: [],
      list: meta.tags,
    });
  }

  // Fonte
  sections.push({
    heading: 'Fonte archivistica',
    paragraphs: [
      `Voce importata dall'Archivio Storico Web ufficiale del Dott. Luca Falace (lucafalace.altervista.org). File sorgente: ${meta.source_file}. Data di pubblicazione originaria: ${meta.date || 'non specificata'}.`,
      "Integrazione totale eseguita in ottemperanza alla direttiva della Fondazione Falace AIC (Operazione: Integrazione Totale ed Espansione dell'Enciclopedia — Regola: Zero Perdite).",
    ],
  });

  return sections;
}

// Build wordpress articles
export const WP_ARTICLES = posts.map((p) => {
  const cleanedTitle = cleanTitle(p.title);
  const cat = inferCategory(cleanedTitle, p.tags || []);
  const sections = blocksToSections(p.blocks || [], p);
  const totalImages = sections.reduce((n, s) => n + ((s.images && s.images.length) || 0), 0);

  return {
    id: p.id,
    slug: `archivio_${p.post_id}_${slug(cleanedTitle) || 'voce'}`,
    title: cleanedTitle,
    category: cat,
    subtitle: `Archivio Storico 1996-2024 · ${p.date || 's.d.'} · Post ID ${p.post_id}`,
    infobox: {
      'ID Archivio': p.post_id,
      Data: p.date || 's.d.',
      Fonte: 'lucafalace.altervista.org',
      Categoria: cat,
      Immagini: String(totalImages),
      Autore: 'Dott. Luca Falace',
    },
    image: (p.images && p.images.length) ? { url: p.images[0], caption: cleanedTitle } : undefined,
    sections,
    seeAlso: ['fondazione_falace_aic', 'luca_falace', 'archivio_storico'],
    references: [
      'Archivio Storico Web ufficiale del Dott. Luca Falace (lucafalace.altervista.org)',
      `File sorgente: ${p.source_file}`,
    ],
  };
});

// Categories added by the WordPress import
export const WP_CATEGORIES = Array.from(new Set(WP_ARTICLES.map((a) => a.category))).sort();
