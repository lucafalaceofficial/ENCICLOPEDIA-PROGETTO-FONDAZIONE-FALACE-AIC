

export const DOCUMENTARY_SERIES = [
  {
    episodeNum: 1,
    title: '2017 – Rai 2 – I Fatti Vostri',
    year: 2017,
    topics: ['Rai 2', 'I Fatti Vostri', 'Invenzioni', 'Brevetti'],
    description: 'Partecipazione televisiva nazionale presso il programma “I Fatti Vostri” su Rai 2, dedicato alla presentazione del brevetto e delle invenzioni.',
    youtubeUrl: 'https://photos.app.goo.gl/26fEASFjDBBtGLJx5'
  },
  {
    episodeNum: 2,
    title: '2015 – Italia 1 – Shark Tank Italia (Mediaset)',
    year: 2015,
    topics: ['Italia 1', 'Shark Tank', 'GeniusOm', 'Fabio Cannavale'],
    description: 'Partecipazione in prima serata su Italia 1 al celebre show "Shark Tank Italia". Presentazione del progetto d\'impresa ecologico "GeniusOm" e trattativa d\'investimento conclusa con successo per un valore di €250.000 (per il 70% delle quote) con il noto investitore Fabio Cannavale, come registrato storiograficamente nella voce ufficiale di Wikipedia.',
    youtubeUrl: 'https://photos.app.goo.gl/sqYuAuEjVBasPG436',
    wikipediaUrl: 'https://it.wikipedia.org/wiki/Shark_Tank_Italia'
  },
  {
    episodeNum: 3,
    title: '2014 – Premio Ecomondo – Green Economy',
    year: 2014,
    topics: ['Ecomondo', 'Presidente Repubblica', 'Eco-Invenzione'],
    description: 'Premio per la migliore invenzione e brevetto per la Green Economy con adesione del Presidente della Repubblica.',
    youtubeUrl: 'https://photos.app.goo.gl/LxV1wkhKHcQp2qCU9'
  },
  {
    episodeNum: 4,
    title: '2013 – Confindustria – Premio Innovazione',
    year: 2013,
    topics: ['Confindustria', 'Premio Innovazione', 'Unione Industriali'],
    description: 'Premio e presentazione del progetto presso contesto Confindustria e Unione Industriali.',
    youtubeUrl: 'https://youtu.be/2UI1tqpVlb0?si=tXfbhY4KegeonBza'
  },
  {
    episodeNum: 5,
    title: '2013 – Intervista Unione Industriali',
    year: 2013,
    topics: ['Intervista', 'Unione Industriali', 'Brevetti'],
    description: 'Intervista istituzionale dedicata all’invenzione e allo sviluppo del brevetto.',
    youtubeUrl: 'https://photos.app.goo.gl/Vt5mJctaZbYGTQaYA'
  }
];
