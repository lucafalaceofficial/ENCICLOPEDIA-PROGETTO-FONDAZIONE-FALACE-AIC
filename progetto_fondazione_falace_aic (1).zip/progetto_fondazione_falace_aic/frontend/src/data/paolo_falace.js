// Paolo Falace (1940–1994) — Attore di teatro, televisione e cinema
// Fonti: Wikipedia, IMDb, MYmovies, Movieplayer, FilmTV.it, il Davinotti,
// Rai Teche, INDA Fondazione, Engramma.

export const PAOLO_FALACE = {
  name: "Paolo Falace",
  born: 1940,
  died: 1994,
  role: "Attore di teatro, televisione e cinema",
  relation:
    "Zio del Dott. Luca Falace — figura di riferimento culturale della famiglia Falace",

  profile: `Paolo Falace (1940–1994) è stato un attore italiano di teatro, televisione e cinema. La sua traiettoria professionale, sviluppatasi per oltre tre decenni nella seconda metà del Novecento, rappresenta una testimonianza di rilievo nell'ambito della cultura teatrale e audiovisiva italiana: un percorso fondato sul rigore interpretativo, sulla versatilità espressiva e su una solida formazione classica.

L'identità artistica di Paolo Falace trova nel teatro il punto di riferimento principale e irrinunciabile: dalla commedia aristofanea alla drammaturgia contemporanea europea, da Shakespeare alla prosa del secondo Novecento. Parallelamente ha partecipato ad alcune delle produzioni più significative della televisione pubblica italiana (Rai) e a lungometraggi del cinema d'autore, lavorando accanto a figure centrali della cinematografia italiana del periodo. La sua ultima e più solenne partecipazione fu al Teatro Greco di Siracusa nel 1994, nella stagione dell'INDA — Istituto Nazionale del Dramma Antico — negli "Acarnesi" di Aristofane, regia di Egisto Marcucci.`,

  // Teatro / prosa televisiva Rai — Archivio Teche Rai
  teatroRai: [
    {
      period: "1966–1967",
      title: "Teatro Rai 1966–1967",
      role: "Carufa, Garzone, Guardiacaccia",
      castNotes:
        "Accanto a Silvano Tranquilli, Maria Capocci, Sergio Reggi, Michele Borelli e Valentina Fortunato",
      source: "Rai Teche — Teatro 1966–1967",
      url: "https://www.teche.rai.it/teatro-1966-1967/"
    },
    {
      period: "1967",
      title: "Tovaritch",
      author: "Jacques Deval",
      director: "Flaminio Bollini",
      channel: "Secondo Programma",
      airDate: "17 maggio 1967",
      source: "Rai Teche — Teatro 1966–1967",
      url: "https://www.teche.rai.it/teatro-1966-1967/"
    },
    {
      period: "1968–1969",
      title: "Incidente a Vichy",
      author: "Arthur Miller",
      director: "Marco Leto",
      role: "Il Poliziotto",
      source: "Rai Teche — Teatro 1968–1969",
      url: "https://www.teche.rai.it/teatro-1968-1969/"
    },
    {
      period: "1978–1979",
      title: "Pluto (Aristofane)",
      director: "Lino Procacci",
      role: "Pluto (protagonista)",
      cast: "Carlo Giuffrè, Giuseppe Pambieri, Lia Tanzi",
      airDate: "28 luglio 1978",
      source: "Rai Teche — Teatro 1978–1979",
      url: "https://www.teche.rai.it/teatro-1978-1979/"
    },
    {
      period: "1981",
      title: "La tempesta (Shakespeare)",
      role: "Trinculo",
      source: "Rai Teche — Teatro 1981",
      url: "https://www.teche.rai.it/teatro-1981-1981/"
    },
    {
      period: "1983–1984",
      title: "Teatro Rai 1983–1984 — inclusa presenza in \"L'avaro\"",
      source: "Rai Teche — Teatro 1983–1984",
      url: "https://www.teche.rai.it/teatro-1983-1984/"
    }
  ],

  // Sceneggiati, fiction e film TV
  filmografiaTV: [
    { year: 1963, title: "Luisa Sanfelice", director: "Leonardo Cortese", note: "Sceneggiato storico Rai", url: "https://www.davinotti.com/film/luisa-sanfelice/71805" },
    { year: 1966, title: "Madame Curie", director: "Guglielmo Morandi", role: "Muzet" },
    { year: 1967, title: "Abramo Lincoln — Cronaca di un delitto", director: "Daniele D'Anza", url: "https://it.wikipedia.org/wiki/Paolo_Falace" },
    { year: 1970, title: "Il cappello del prete", note: "Miniserie televisiva ep. 1x03", url: "https://www.teche.rai.it/sceneggiati-e-fiction-1970-1973/" },
    { year: 1971, title: "Oltre il duemila", director: "Piero Nelli", note: "ep. 1x01" },
    { year: 1972, title: "Le inchieste del commissario Maigret — Maigret in pensione", director: "Mario Landi", role: "Oscar" },
    { year: 1974, title: "Processo al generale Baratieri per la sconfitta di Adua", director: "Piero Schivazappa", url: "https://www.imdb.com/title/tt0172042/" },
    { year: 1976, title: "Dov'è Anna?", director: "Piero Schivazappa", role: "Huerta", url: "https://www.teche.rai.it/sceneggiati-e-fiction-1975-1977/" },
    { year: 1977, title: "Lo scandalo della Banca Romana", director: "Luigi Perelli", note: "ep. 1x01–1x03", url: "https://www.davinotti.com/film/lo-scandalo-della-banca-romana/55319" },
    { year: 1977, title: "Vedrai che cambierà", director: "Paolo Poeti", note: "Film TV su Luigi Tenco — trasmesso 21 dicembre 1977", url: "https://www.davinotti.com/film/vedrai-che-cambiera/33615" },
    { year: 1979, title: "L'affare Stavisky", note: "Miniserie ep. 1x01–1x03", url: "https://www.teche.rai.it/sceneggiati-e-fiction-1980-1982/" },
    { year: 1979, title: "Ma che cosa è quest'amore", director: "Ugo Gregoretti", note: "Rete Uno, 6 e 8 novembre 1979", url: "https://www.davinotti.com/film/ma-che-cosa-e-quest-amore/47584" },
    { year: 1979, title: "Il delitto Notarbartolo", note: "Produzione Rai", url: "https://www.teche.rai.it/sceneggiati-e-fiction-1978-1980/" },
    { year: 1980, title: "Tre operai", director: "Francesco Maselli", note: "ep. 1x01–1x02", url: "https://www.filmtv.it/persona/221614/paolo-falace/" },
    { year: 1981, title: "La casa rossa", director: "Delmer Daves", note: "Miniserie in 5 episodi" },
    { year: 1983, title: "L'avventura di un fotografo (Dieci registi italiani, dieci racconti italiani)", director: "Francesco Maselli", role: "Antonino", url: "https://www.mymovies.it/persone/paolo-falace/5722/filmografia/" },
    { year: 1986, title: "Il cugino americano (Blood Ties)", director: "Giacomo Battiato", note: "Rai 1, 12–19 ottobre 1986", url: "https://www.davinotti.com/film/il-cugino-americano/33660" },
    { year: 1987, title: "Nessuno torna indietro", role: "Blanchette Brundy", note: "ep. 1x01–1x03", url: "https://www.teche.rai.it/sceneggiati-e-fiction-1986-1989/" },
    { year: 1987, title: "La voglia di vincere", director: "Vittorio Sindoni", note: "Miniserie in 3 puntate", url: "https://www.filmtv.it/persona/221614/paolo-falace/" },
    { year: 1993, title: "Stay Lucky", note: "Serie TV britannica — episodio 4x10" }
  ],

  // Cinema
  filmografiaCinema: [
    { year: 1972, title: "Donnarumma all'assalto", director: "Marco Leto", url: "https://www.imdb.com/name/nm0265827/" },
    { year: 1986, title: "Il tenente dei carabinieri", director: "Maurizio Ponzi", note: "Cast: Nino Manfredi, Enrico Montesano, Massimo Boldi, Marisa Laurito", url: "https://movieplayer.it/personaggi/paolo-falace_222090/" },
    { year: 1989, title: "'o Re", director: "Luigi Magni", role: "Chiavone", note: "Commedia storica italo-americana", url: "https://it.wikipedia.org/wiki/Paolo_Falace" }
  ],

  // INDA 1994
  indaSiracusa1994: {
    title: "Acarnesi (Aristofane) — INDA Siracusa 1994",
    role: "Teóro",
    director: "Egisto Marcucci",
    music: "Franco Piersanti",
    scenography: "Graziano Gregori",
    cast: "Marcello Bartoli (Diceopoli), Giovanni Grasso (Araldo), Ulderico Pesce (Anfiteo), Renato Campisi (Ambasciatore), Gianluca Riggi (Pseudartaba)",
    context:
      "Ultima e più solenne partecipazione teatrale: il Teatro Greco di Siracusa nel 1994 nella stagione dell'INDA (Istituto Nazionale del Dramma Antico). La stagione includeva anche il \"Prometeo\" di Eschilo (regia di Antonio Calenda) e le \"Coefore\" di Eschilo (regia di Giorgio Pressburger, musiche di Philip Glass).",
    sources: [
      { label: "INDA Fondazione — Acarnesi 1994", url: "https://www.indafondazione.org/en/acarnesi-di-aristofane-2/" },
      { label: "Engramma — Regesto spettacoli INDA", url: "https://www.engramma.it/eOS/index.php?id_articolo=5143" },
      { label: "Fondazione INDA — Acarnesi 1994 (video)", url: "https://www.facebook.com/fondazioneinda/videos/acarnesi-1994/681121389112614/" }
    ]
  },

  // Fonti principali
  fontiPrincipali: [
    { label: "Wikipedia Italia — Paolo Falace", url: "https://it.wikipedia.org/wiki/Paolo_Falace" },
    { label: "IMDb — Paolo Falace", url: "https://www.imdb.com/name/nm0265827/" },
    { label: "MYmovies — Biografia", url: "https://www.mymovies.it/persone/paolo-falace/5722/" },
    { label: "MYmovies — Filmografia", url: "https://www.mymovies.it/persone/paolo-falace/5722/filmografia/" },
    { label: "Movieplayer.it — Paolo Falace", url: "https://movieplayer.it/personaggi/paolo-falace_222090/" },
    { label: "FilmTV.it — Paolo Falace", url: "https://www.filmtv.it/persona/221614/paolo-falace/" },
    { label: "il Davinotti — Paolo Falace (attore)", url: "https://www.davinotti.com/film/cerca-attore/Paolo%20Falace" },
    { label: "PeoplePill — Paolo Falace", url: "https://peoplepill.com/i/paolo-falace/" }
  ],

  // Immagine (dominio pubblico / rappresentativa)
  photoUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Teatro_greco_di_Siracusa_-_panoramio.jpg/640px-Teatro_greco_di_Siracusa_-_panoramio.jpg",
  photoCaption: "Teatro Greco di Siracusa — sede dell'INDA e ultimo palcoscenico di Paolo Falace (1994)."
};
