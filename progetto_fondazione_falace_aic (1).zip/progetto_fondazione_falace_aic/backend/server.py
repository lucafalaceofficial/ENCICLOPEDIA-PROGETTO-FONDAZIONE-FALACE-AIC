from fastapi import FastAPI, APIRouter
from fastapi.responses import StreamingResponse, JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import io
import json
import zipfile
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List
import uuid
from datetime import datetime, timezone


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI(title="Enciclopedia Fondazione Falace AIC")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class StatusCheckCreate(BaseModel):
    client_name: str


@api_router.get("/")
async def root():
    return {"message": "Enciclopedia Fondazione Falace AIC — API attiva"}


@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.model_dump()
    status_obj = StatusCheck(**status_dict)
    doc = status_obj.model_dump()
    doc['timestamp'] = doc['timestamp'].isoformat()
    _ = await db.status_checks.insert_one(doc)
    return status_obj


@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    status_checks = await db.status_checks.find({}, {"_id": 0}).to_list(1000)
    for check in status_checks:
        if isinstance(check.get('timestamp'), str):
            check['timestamp'] = datetime.fromisoformat(check['timestamp'])
    return status_checks


# ============ ENCYCLOPEDIA DATA LOADER ============
FRONTEND_SRC = Path("/app/frontend/src")
DATA_DIR = FRONTEND_SRC / "data"


def _articles_from_data() -> list:
    """Load articles from the pre-generated JSON snapshot."""
    snapshot = DATA_DIR / "articles_snapshot.json"
    if snapshot.exists():
        try:
            return json.loads(snapshot.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


@api_router.get("/articles")
async def list_articles():
    arts = _articles_from_data()
    return {"articles": arts, "count": len(arts)}


@api_router.get("/download/json")
async def download_json():
    """Download the full dataset as a JSON archive."""
    data = {
        "portal": "Progetto Fondazione Falace delle Attività Intellettive Creative AIC",
        "author": "Dott. Luca Falace",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "articles": _articles_from_data(),
    }
    payload = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    return StreamingResponse(
        io.BytesIO(payload),
        media_type="application/json",
        headers={
            "Content-Disposition": 'attachment; filename="fondazione_falace_aic_dati.json"'
        },
    )


def _walk_files(base: Path, skip_dirs=("node_modules", ".git", "build", "dist", "__pycache__")):
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith(".")]
        for f in files:
            if f.endswith((".pyc", ".log")):
                continue
            p = Path(root) / f
            try:
                if p.stat().st_size > 25 * 1024 * 1024:
                    continue
            except OSError:
                continue
            yield p


@api_router.get("/download/zip")
async def download_full_zip():
    """Download the full source code of the portal as ZIP."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # Frontend source
        for p in _walk_files(Path("/app/frontend/src")):
            zf.write(p, arcname=str(Path("progetto_fondazione_falace_aic") / p.relative_to("/app")))
        # public / config
        for extra in [
            Path("/app/frontend/package.json"),
            Path("/app/frontend/tailwind.config.js"),
            Path("/app/frontend/postcss.config.js"),
            Path("/app/frontend/craco.config.js"),
            Path("/app/frontend/public/index.html"),
        ]:
            if extra.exists():
                zf.write(extra, arcname=str(Path("progetto_fondazione_falace_aic") / extra.relative_to("/app")))
        # Backend
        for p in _walk_files(Path("/app/backend")):
            zf.write(p, arcname=str(Path("progetto_fondazione_falace_aic") / p.relative_to("/app")))
        # README
        readme = (
            "# Progetto Fondazione Falace delle Attività Intellettive Creative AIC\n\n"
            "Enciclopedia in stile Wikipedia dedicata al patrimonio del Dott. Luca Falace.\n\n"
            "## Struttura\n"
            "- `frontend/`: applicazione React con architettura Wikipedia-like\n"
            "- `backend/`: FastAPI con endpoint di download (ZIP / JSON / HTML)\n\n"
            "## Sezioni principali\n"
            "- Biblioteca (50 monografie)\n"
            "- Bibliografia (brevetti UIBM, Google Patents)\n"
            "- Biografia (Luca Falace, Lucio Falace, tradizione familiare)\n"
            "- Media (apparizioni televisive MEDIASET, RAI 2, Premio Ecomondo)\n\n"
            "Generato automaticamente dal portale.\n"
        )
        zf.writestr("progetto_fondazione_falace_aic/README.md", readme)
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={
            "Content-Disposition": 'attachment; filename="progetto_fondazione_falace_aic.zip"'
        },
    )


def _render_article_html(a: dict) -> str:
    parts = [
        f"<h1>{a.get('title','')}</h1>",
        f"<p><em>{a.get('subtitle','')}</em></p>",
    ]
    for s in a.get("sections", []):
        parts.append(f"<h2>{s.get('heading','')}</h2>")
        for p in s.get("paragraphs", []) or []:
            parts.append(f"<p>{p}</p>")
        if s.get("list"):
            parts.append("<ul>" + "".join(f"<li>{x}</li>" for x in s["list"]) + "</ul>")
        if s.get("images"):
            for img in s["images"]:
                parts.append(f'<figure><img src="{img}" style="max-width:100%"/></figure>')
        if s.get("table"):
            t = s["table"]
            parts.append("<table border=1 cellspacing=0 cellpadding=6>")
            parts.append("<tr>" + "".join(f"<th>{h}</th>" for h in t["headers"]) + "</tr>")
            for row in t["rows"]:
                parts.append("<tr>" + "".join(f"<td>{c}</td>" for c in row) + "</tr>")
            parts.append("</table>")
    if a.get("references"):
        parts.append("<h2>Note e riferimenti</h2><ol>")
        parts.extend(f"<li>{r}</li>" for r in a["references"])
        parts.append("</ol>")
    return "\n".join(parts)


@api_router.get("/download/html")
async def download_html_site():
    """Generate a static HTML archive of the encyclopedia."""
    buf = io.BytesIO()
    articles = _articles_from_data()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        base_css = (
            "body{font-family:'Noto Serif',Georgia,serif;background:#fff;color:#202122;"
            "max-width:900px;margin:20px auto;padding:0 20px;line-height:1.6;}"
            "h1{border-bottom:1px solid #a2a9b1;font-weight:400;font-size:28px;}"
            "h2{border-bottom:1px solid #a2a9b1;font-weight:400;font-size:22px;margin-top:24px;}"
            "table{border-collapse:collapse;margin:12px 0;font-size:13px;background:#f8f9fa;}"
            "th{background:#eaecf0;text-align:left;padding:6px 10px;border:1px solid #c8ccd1;}"
            "td{padding:6px 10px;border:1px solid #c8ccd1;vertical-align:top;}"
            "a{color:#3366cc;text-decoration:none;} a:hover{text-decoration:underline;}"
            "nav a{margin-right:8px;} figure{margin:12px 0;} img{max-width:100%;height:auto;}"
        )
        zf.writestr("progetto_fondazione_falace_aic_html/style.css", base_css)

        # Index page
        index_body = ["<h1>Enciclopedia Fondazione Falace AIC</h1>",
                      f"<p>Voci: <strong>{len(articles)}</strong></p><ul>"]
        for a in sorted(articles, key=lambda x: x.get("title", "")):
            index_body.append(f'<li><a href="wiki/{a["slug"]}.html">{a["title"]}</a> — <em>{a["category"]}</em></li>')
        index_body.append("</ul>")
        zf.writestr(
            "progetto_fondazione_falace_aic_html/index.html",
            f'<!doctype html><html lang="it"><head><meta charset="utf-8">'
            f'<title>Enciclopedia Fondazione Falace AIC</title>'
            f'<link rel="stylesheet" href="style.css"></head><body>'
            f'{"".join(index_body)}</body></html>',
        )

        for a in articles:
            body = _render_article_html(a)
            html = (
                f'<!doctype html><html lang="it"><head><meta charset="utf-8">'
                f'<title>{a.get("title","")} — Fondazione Falace AIC</title>'
                f'<link rel="stylesheet" href="../style.css"></head><body>'
                f'<nav><a href="../index.html">← Indice</a></nav>'
                f'{body}</body></html>'
            )
            zf.writestr(f"progetto_fondazione_falace_aic_html/wiki/{a['slug']}.html", html)
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={
            "Content-Disposition": 'attachment; filename="progetto_fondazione_falace_aic_html.zip"'
        },
    )


# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@app.on_event("startup")
async def startup_cleanup():
    """Drop old collections from the previous Facebook-style archive (one-time cleanup)."""
    try:
        existing = await db.list_collection_names()
        for old in ('posts', 'attachments', 'categories', 'site'):
            if old in existing:
                await db.drop_collection(old)
                logger.info(f"Dropped obsolete collection: {old}")
    except Exception as e:
        logger.warning(f"Startup cleanup skipped: {e}")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
