"""
Backend API tests for Archivio Storico - Dott. Luca Falace
Covers: site-info, posts (list/filter/search/get), categories, attachments, years.
"""
import os
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://luca-falace-archive.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"


@pytest.fixture(scope="session")
def client():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# ---------- Site info ----------
class TestSiteInfo:
    def test_site_info_shape_and_stats(self, client):
        r = client.get(f"{API}/site-info", timeout=30)
        assert r.status_code == 200
        data = r.json()
        assert "site" in data and "stats" in data
        stats = data["stats"]
        assert stats["posts"] == 36
        assert stats["pages"] == 86
        assert stats["total_entries"] == 122
        assert stats["attachments"] == 1286
        assert stats["categories"] == 56
        assert isinstance(stats["years"], list)
        assert stats["year_min"] > 0
        assert stats["year_max"] >= stats["year_min"]


# ---------- Posts listing ----------
class TestPostsList:
    def test_list_all_posts_default(self, client):
        r = client.get(f"{API}/posts", timeout=30)
        assert r.status_code == 200
        data = r.json()
        assert data["total"] == 122
        assert isinstance(data["items"], list)
        # sort desc by date (newest first)
        dates = [it.get("date") for it in data["items"] if it.get("date")]
        assert dates == sorted(dates, reverse=True)

    def test_pagination(self, client):
        r = client.get(f"{API}/posts", params={"limit": 5, "skip": 0}, timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["limit"] == 5
        assert d["skip"] == 0
        assert len(d["items"]) == 5
        # next page
        r2 = client.get(f"{API}/posts", params={"limit": 5, "skip": 5}, timeout=30)
        d2 = r2.json()
        assert len(d2["items"]) == 5
        # no overlap
        first_ids = {it["id"] for it in d["items"]}
        second_ids = {it["id"] for it in d2["items"]}
        assert first_ids.isdisjoint(second_ids)

    def test_filter_year_2017(self, client):
        r = client.get(f"{API}/posts", params={"year": 2017, "limit": 200}, timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["total"] >= 0
        for it in d["items"]:
            assert it.get("year") == 2017

    def test_filter_type_post(self, client):
        r = client.get(f"{API}/posts", params={"type": "post", "limit": 200}, timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["total"] == 36
        for it in d["items"]:
            assert it.get("type") == "post"

    def test_filter_type_page(self, client):
        r = client.get(f"{API}/posts", params={"type": "page", "limit": 200}, timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["total"] == 86
        for it in d["items"]:
            assert it.get("type") == "page"

    def test_filter_category(self, client):
        # Get a valid category slug from categories endpoint
        cats = client.get(f"{API}/categories", timeout=30).json()["items"]
        assert cats, "No categories returned"
        slug = cats[0]["slug"]
        r = client.get(f"{API}/posts", params={"category": slug, "limit": 200}, timeout=30)
        assert r.status_code == 200
        d = r.json()
        for it in d["items"]:
            slugs = [c.get("slug") for c in it.get("categories", [])]
            assert slug in slugs

    def test_search_case_insensitive(self, client):
        # Search a common Italian word
        r = client.get(f"{API}/posts", params={"q": "LUCA", "limit": 20}, timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["total"] >= 0
        # ensure lowercase yields same or comparable results
        r2 = client.get(f"{API}/posts", params={"q": "luca", "limit": 20}, timeout=30)
        assert r2.json()["total"] == d["total"]

    def test_combined_filters_year_and_category(self, client):
        cats = client.get(f"{API}/categories", timeout=30).json()["items"]
        slug = cats[0]["slug"]
        r = client.get(f"{API}/posts", params={"year": 2017, "category": slug, "limit": 200}, timeout=30)
        assert r.status_code == 200
        for it in r.json()["items"]:
            assert it.get("year") == 2017
            slugs = [c.get("slug") for c in it.get("categories", [])]
            assert slug in slugs


# ---------- Single post ----------
class TestGetPost:
    def test_get_by_uuid_id(self, client):
        listing = client.get(f"{API}/posts", params={"limit": 1}, timeout=30).json()
        assert listing["items"]
        pid = listing["items"][0]["id"]
        r = client.get(f"{API}/posts/{pid}", timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["id"] == pid
        assert "content_html" in d
        assert "categories" in d

    def test_get_by_numeric_post_id(self, client):
        listing = client.get(f"{API}/posts", params={"limit": 5}, timeout=30).json()
        item = next((x for x in listing["items"] if x.get("post_id")), None)
        assert item, "No item has numeric post_id"
        r = client.get(f"{API}/posts/{item['post_id']}", timeout=30)
        assert r.status_code == 200
        assert r.json()["id"] == item["id"]

    def test_get_by_slug(self, client):
        listing = client.get(f"{API}/posts", params={"limit": 5}, timeout=30).json()
        item = next((x for x in listing["items"] if x.get("slug")), None)
        assert item, "No item with slug"
        r = client.get(f"{API}/posts/{item['slug']}", timeout=30)
        assert r.status_code == 200
        assert r.json()["id"] == item["id"]

    def test_get_invalid_id_returns_404(self, client):
        r = client.get(f"{API}/posts/invalid_id_xyz_nonexistent", timeout=30)
        assert r.status_code == 404


# ---------- Categories ----------
class TestCategories:
    def test_list_categories(self, client):
        r = client.get(f"{API}/categories", timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["total"] == 56
        assert len(d["items"]) == 56
        # sorted by count desc
        counts = [it.get("count", 0) for it in d["items"]]
        assert counts == sorted(counts, reverse=True)
        # each item shape
        it0 = d["items"][0]
        assert "slug" in it0 and "name" in it0


# ---------- Attachments ----------
class TestAttachments:
    def test_list_attachments_default(self, client):
        r = client.get(f"{API}/attachments", timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["total"] == 1286
        assert len(d["items"]) == 48  # default limit

    def test_attachments_pagination(self, client):
        r = client.get(f"{API}/attachments", params={"limit": 10, "skip": 20}, timeout=30)
        assert r.status_code == 200
        d = r.json()
        assert d["limit"] == 10
        assert d["skip"] == 20
        assert len(d["items"]) == 10

    def test_attachments_year_filter(self, client):
        r = client.get(f"{API}/attachments", params={"year": 2017, "limit": 500}, timeout=30)
        assert r.status_code == 200
        for it in r.json()["items"]:
            assert it.get("year") == 2017


# ---------- Years ----------
class TestYears:
    def test_years_aggregation(self, client):
        r = client.get(f"{API}/years", timeout=30)
        assert r.status_code == 200
        items = r.json()["items"]
        assert len(items) > 0
        years = [it["year"] for it in items]
        assert years == sorted(years)  # ascending
        for it in items:
            assert it["count"] > 0
